import { useEffect, useRef, useState } from "react";
import { Landmark, Flame, Lock, Sparkles } from "lucide-react";
import { useLang } from "@/i18n/LanguageProvider";

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const ICONS = [Landmark, Flame, Lock, Sparkles];
const NUMBERS = ["01", "02", "03", "04"];
const COLORS = [
  { color: "#FFD700", bg: "rgba(255,215,0,0.08)", border: "rgba(255,215,0,0.2)" },
  { color: "#FF6B35", bg: "rgba(255,107,53,0.08)", border: "rgba(255,107,53,0.2)" },
  { color: "#60A5FA", bg: "rgba(96,165,250,0.08)", border: "rgba(96,165,250,0.2)" },
  { color: "#C084FC", bg: "rgba(192,132,252,0.08)", border: "rgba(192,132,252,0.2)" },
];

export const WhyChoose = () => {
  const { t } = useLang();
  const { ref, inView } = useInView(0.1);

  const items = [
    { Icon: ICONS[0], title: t("why.i1.title"), desc: t("why.i1.desc"), ...COLORS[0], num: NUMBERS[0] },
    { Icon: ICONS[1], title: t("why.i2.title"), desc: t("why.i2.desc"), ...COLORS[1], num: NUMBERS[1] },
    { Icon: ICONS[2], title: t("why.i3.title"), desc: t("why.i3.desc"), ...COLORS[2], num: NUMBERS[2] },
    { Icon: ICONS[3], title: t("why.i4.title"), desc: t("why.i4.desc"), ...COLORS[3], num: NUMBERS[3] },
  ];

  return (
    <section
      className="relative py-28 overflow-hidden"
      ref={ref as React.RefObject<HTMLElement>}
      style={{ background: "linear-gradient(180deg,#050505 0%,#030208 50%,#050505 100%)" }}
    >
      {/* Large Om watermark */}
      <div
        className="absolute inset-0 flex items-center justify-center pointer-events-none select-none"
        style={{
          fontSize: "clamp(18rem, 40vw, 32rem)",
          color: "rgba(255,215,0,0.015)",
          fontFamily: "Cinzel, serif",
          lineHeight: 1,
          userSelect: "none",
        }}
      >
        ॐ
      </div>

      {/* Ambient glows */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-96 h-96 pointer-events-none"
        style={{ background: "radial-gradient(circle at left, rgba(255,215,0,0.04) 0%, transparent 70%)" }} />
      <div className="absolute top-1/2 right-0 -translate-y-1/2 w-96 h-96 pointer-events-none"
        style={{ background: "radial-gradient(circle at right, rgba(192,132,252,0.04) 0%, transparent 70%)" }} />

      <div className="container relative z-10">
        {/* Section label */}
        <div className={`flex items-center justify-center gap-3 mb-6 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <span className="h-px w-16 bg-gradient-to-r from-transparent to-yellow-500/60" />
          <p className="text-xs tracking-[0.45em] text-yellow-400 font-[Cinzel] uppercase">
            {t("why.kicker")}
          </p>
          <span className="h-px w-16 bg-gradient-to-l from-transparent to-yellow-500/60" />
        </div>

        {/* Heading */}
        <div className={`text-center mb-16 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`} style={{ transitionDelay: "100ms" }}>
          <h2 className="text-3xl md:text-5xl font-bold font-[Cinzel]" style={{ textShadow: "0 0 20px rgba(255,215,0,0.12)" }}>
            {t("why.title.1")}{" "}
            <span style={{
              background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
              backgroundSize: "200% 200%", animation: "goldShimmer 4s ease infinite",
            }}>
              {t("why.title.gold")}
            </span>
          </h2>
        </div>

        {/* Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map((item, idx) => (
            <div
              key={item.title}
              className={`group relative rounded-2xl p-7 transition-all duration-700 cursor-default ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
              style={{
                transitionDelay: `${200 + idx * 120}ms`,
                background: "rgba(8,6,12,0.9)",
                border: `1px solid ${item.border}`,
                backdropFilter: "blur(12px)",
              }}
              onMouseEnter={(e) => {
                const el = e.currentTarget as HTMLElement;
                el.style.boxShadow = `0 0 40px ${item.bg}, 0 20px 50px rgba(0,0,0,0.4)`;
                el.style.transform = "translateY(-6px)";
                el.style.borderColor = item.color + "55";
              }}
              onMouseLeave={(e) => {
                const el = e.currentTarget as HTMLElement;
                el.style.boxShadow = "none";
                el.style.transform = "translateY(0)";
                el.style.borderColor = item.border;
              }}
            >
              {/* Big number watermark */}
              <div
                className="absolute top-4 right-5 font-[Cinzel] font-bold text-5xl leading-none pointer-events-none select-none transition-all duration-500 group-hover:opacity-40"
                style={{ color: item.color, opacity: 0.1 }}
              >
                {item.num}
              </div>

              {/* Top accent line */}
              <div className="absolute top-0 left-6 right-6 h-px"
                style={{ background: `linear-gradient(90deg, transparent, ${item.color}60, transparent)` }} />

              {/* Icon */}
              <div
                className="w-14 h-14 rounded-2xl grid place-items-center mb-6 transition-all duration-500 group-hover:scale-110"
                style={{ background: item.bg, border: `1px solid ${item.border}` }}
              >
                <item.Icon className="size-6" style={{ color: item.color }} />
              </div>

              {/* Content */}
              <h3 className="text-lg font-bold font-[Cinzel] text-white mb-3 leading-snug">{item.title}</h3>
              <p className="text-sm text-white/45 leading-relaxed">{item.desc}</p>

              {/* Bottom connector dot */}
              <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                style={{ background: item.color }} />
            </div>
          ))}
        </div>

        {/* Stats strip */}
        <div
          className={`mt-20 grid grid-cols-2 md:grid-cols-4 gap-px transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          style={{
            transitionDelay: "700ms",
            background: "rgba(255,215,0,0.08)",
            border: "1px solid rgba(255,215,0,0.12)",
            borderRadius: "1rem",
            overflow: "hidden",
          }}
        >
          {[
            { num: "15+", label: "Years Experience" },
            { num: "5000+", label: "Rituals Done" },
            { num: "21", label: "States Covered" },
            { num: "100%", label: "Shastriya Vidhi" },
          ].map((stat, i) => (
            <div
              key={stat.label}
              className="flex flex-col items-center justify-center py-7 px-4 text-center"
              style={{ background: i % 2 === 0 ? "rgba(255,215,0,0.03)" : "rgba(0,0,0,0.3)" }}
            >
              <span className="text-3xl font-bold font-[Cinzel] text-yellow-400"
                style={{ textShadow: "0 0 20px rgba(255,215,0,0.4)" }}>
                {stat.num}
              </span>
              <span className="text-[11px] uppercase tracking-widest text-white/40 mt-1">{stat.label}</span>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes goldShimmer {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>
    </section>
  );
};
