import { useEffect, useRef, useState, useCallback } from "react";
import { Quote, Star, ChevronLeft, ChevronRight } from "lucide-react";
import { useLang } from "@/i18n/LanguageProvider";

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const AVATAR_COLORS = [
  { bg: "rgba(255,215,0,0.15)", border: "rgba(255,215,0,0.4)", text: "#FFD700" },
  { bg: "rgba(255,107,53,0.15)", border: "rgba(255,107,53,0.4)", text: "#FF6B35" },
  { bg: "rgba(96,165,250,0.15)", border: "rgba(96,165,250,0.4)", text: "#60A5FA" },
  { bg: "rgba(192,132,252,0.15)", border: "rgba(192,132,252,0.4)", text: "#C084FC" },
  { bg: "rgba(74,222,128,0.15)", border: "rgba(74,222,128,0.4)", text: "#4ADE80" },
];

export const Testimonials = () => {
  const { t } = useLang();
  const { ref, inView } = useInView(0.1);
  const [active, setActive] = useState(0);
  const [animating, setAnimating] = useState(false);
  const autoRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const items = [
    { text: t("test.t1.text"), name: t("test.t1.name"), place: t("test.t1.place"), stars: 5 },
    { text: t("test.t2.text"), name: t("test.t2.name"), place: t("test.t2.place"), stars: 5 },
    { text: t("test.t3.text"), name: t("test.t3.name"), place: t("test.t3.place"), stars: 5 },
    { text: "माँ बगलामुखी की कृपा से मेरा व्यापार बढ़ा। हवन बहुत शास्त्रीय विधि से हुआ।", name: "Ramesh Patel", place: "Ahmedabad", stars: 5 },
    { text: "Court case में जीत मिली। पंडित जी का मार्गदर्शन अद्भुत था। पुनः बुकिंग करेंगे।", name: "Sunita Sharma", place: "Jaipur", stars: 5 },
  ];

  const goTo = useCallback((idx: number) => {
    if (animating) return;
    setAnimating(true);
    setActive(idx);
    setTimeout(() => setAnimating(false), 400);
  }, [animating]);

  const prev = useCallback(() => goTo((active - 1 + items.length) % items.length), [active, goTo, items.length]);
  const next = useCallback(() => goTo((active + 1) % items.length), [active, goTo, items.length]);

  // Auto-advance
  useEffect(() => {
    if (!inView) return;
    autoRef.current = setInterval(next, 5000);
    return () => { if (autoRef.current) clearInterval(autoRef.current); };
  }, [inView, next]);

  const resetAuto = () => {
    if (autoRef.current) clearInterval(autoRef.current);
    autoRef.current = setInterval(next, 5000);
  };

  const handlePrev = () => { prev(); resetAuto(); };
  const handleNext = () => { next(); resetAuto(); };

  // Display: show 3 cards centered on active (desktop), 1 on mobile
  const getVisible = () => {
    const result = [];
    for (let i = -1; i <= 1; i++) {
      const idx = (active + i + items.length) % items.length;
      result.push({ idx, offset: i });
    }
    return result;
  };

  return (
    <section
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-28 overflow-hidden"
      style={{ background: "linear-gradient(180deg,#050505 0%,#060408 50%,#050505 100%)" }}
    >
      {/* Ambient glows */}
      <div className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse 60% 50% at 50% 50%, rgba(255,215,0,0.03) 0%, transparent 70%)" }} />

      <div className="container relative z-10">
        {/* Section label */}
        <div className={`flex items-center justify-center gap-3 mb-6 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <span className="h-px w-16 bg-gradient-to-r from-transparent to-yellow-500/60" />
          <p className="text-xs tracking-[0.45em] text-yellow-400 font-[Cinzel] uppercase">
            {t("test.kicker")}
          </p>
          <span className="h-px w-16 bg-gradient-to-l from-transparent to-yellow-500/60" />
        </div>

        {/* Heading */}
        <div className={`text-center mb-16 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`} style={{ transitionDelay: "100ms" }}>
          <h2 className="text-3xl md:text-5xl font-bold font-[Cinzel]" style={{ textShadow: "0 0 20px rgba(255,215,0,0.12)" }}>
            {t("test.title.1")}{" "}
            <span style={{
              background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
              backgroundSize: "200% 200%", animation: "goldShimmer 4s ease infinite",
            }}>
              {t("test.title.gold")}
            </span>
          </h2>
          <p className="text-white/40 text-sm mt-3">
            Real devotees, real experiences, divine blessings
          </p>
        </div>

        {/* Carousel — 3 cards on desktop, 1 on mobile */}
        <div className={`transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`} style={{ transitionDelay: "200ms" }}>

          {/* Desktop 3-card layout */}
          <div className="hidden md:flex items-center justify-center gap-5 min-h-[320px]">
            {getVisible().map(({ idx, offset }) => {
              const item = items[idx];
              const color = AVATAR_COLORS[idx % AVATAR_COLORS.length];
              const isCenter = offset === 0;
              const initial = item.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();

              return (
                <div
                  key={idx}
                  onClick={() => { if (!isCenter) { goTo(idx); resetAuto(); } }}
                  className="relative rounded-2xl transition-all duration-500"
                  style={{
                    width: isCenter ? "420px" : "300px",
                    flex: isCenter ? "0 0 420px" : "0 0 300px",
                    opacity: isCenter ? 1 : 0.45,
                    transform: isCenter ? "scale(1) translateY(0)" : `scale(0.92) translateY(${offset < 0 ? "8px" : "8px"})`,
                    background: isCenter ? "rgba(15,12,5,0.98)" : "rgba(10,8,4,0.7)",
                    border: isCenter ? "1px solid rgba(255,215,0,0.25)" : "1px solid rgba(255,255,255,0.05)",
                    boxShadow: isCenter ? "0 0 50px rgba(255,215,0,0.08), 0 30px 60px rgba(0,0,0,0.6)" : "none",
                    cursor: isCenter ? "default" : "pointer",
                    padding: "2rem",
                  }}
                >
                  {isCenter && (
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-px h-px w-3/4"
                      style={{ background: "linear-gradient(90deg, transparent, rgba(255,215,0,0.5), transparent)" }} />
                  )}

                  {/* Quote icon */}
                  <div className="mb-5 flex items-center justify-between">
                    <Quote className="size-7" style={{ color: isCenter ? "rgba(255,215,0,0.5)" : "rgba(255,255,255,0.1)" }} />
                    <div className="flex gap-0.5">
                      {Array.from({ length: item.stars }).map((_, i) => (
                        <Star key={i} className="size-3.5 fill-current" style={{ color: isCenter ? "#FFD700" : "rgba(255,215,0,0.3)" }} />
                      ))}
                    </div>
                  </div>

                  {/* Text */}
                  <blockquote className="text-sm leading-relaxed mb-6"
                    style={{ color: isCenter ? "rgba(255,255,255,0.85)" : "rgba(255,255,255,0.4)" }}>
                    "{item.text}"
                  </blockquote>

                  {/* Author */}
                  <div className="flex items-center gap-3 pt-4" style={{ borderTop: `1px solid ${isCenter ? "rgba(255,215,0,0.1)" : "rgba(255,255,255,0.05)"}` }}>
                    <div className="w-10 h-10 rounded-full grid place-items-center text-sm font-bold font-[Cinzel] flex-shrink-0"
                      style={{ background: isCenter ? color.bg : "rgba(255,255,255,0.05)", border: `1px solid ${isCenter ? color.border : "rgba(255,255,255,0.1)"}`, color: isCenter ? color.text : "rgba(255,255,255,0.3)" }}>
                      {initial}
                    </div>
                    <div>
                      <div className="text-sm font-semibold" style={{ color: isCenter ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.3)" }}>{item.name}</div>
                      <div className="text-xs" style={{ color: isCenter ? "rgba(255,215,0,0.6)" : "rgba(255,255,255,0.2)" }}>
                        {item.place} · {t("test.verified")}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Mobile single card */}
          <div className="md:hidden px-4">
            {(() => {
              const item = items[active];
              const color = AVATAR_COLORS[active % AVATAR_COLORS.length];
              const initial = item.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
              return (
                <div
                  className="rounded-2xl p-7 transition-all duration-400"
                  style={{
                    background: "rgba(15,12,5,0.98)",
                    border: "1px solid rgba(255,215,0,0.2)",
                    boxShadow: "0 0 40px rgba(255,215,0,0.06), 0 20px 50px rgba(0,0,0,0.6)",
                    opacity: animating ? 0 : 1,
                  }}
                >
                  <div className="flex items-center justify-between mb-5">
                    <Quote className="size-7 text-yellow-400/50" />
                    <div className="flex gap-0.5">
                      {Array.from({ length: item.stars }).map((_, i) => (
                        <Star key={i} className="size-3.5 fill-current text-yellow-400" />
                      ))}
                    </div>
                  </div>
                  <blockquote className="text-sm text-white/80 leading-relaxed mb-6">"{item.text}"</blockquote>
                  <div className="flex items-center gap-3 pt-4 border-t border-yellow-400/10">
                    <div className="w-10 h-10 rounded-full grid place-items-center text-sm font-bold font-[Cinzel] flex-shrink-0"
                      style={{ background: color.bg, border: `1px solid ${color.border}`, color: color.text }}>
                      {initial}
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-white/90">{item.name}</div>
                      <div className="text-xs text-yellow-400/60">{item.place} · {t("test.verified")}</div>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-4 mt-10">
            <button
              onClick={handlePrev}
              className="w-10 h-10 rounded-full grid place-items-center border transition-all duration-300 hover:scale-110"
              style={{ background: "rgba(255,215,0,0.08)", border: "1px solid rgba(255,215,0,0.2)", color: "rgba(255,215,0,0.7)" }}
            >
              <ChevronLeft className="size-5" />
            </button>

            {/* Dots */}
            <div className="flex gap-2">
              {items.map((_, i) => (
                <button
                  key={i}
                  onClick={() => { goTo(i); resetAuto(); }}
                  className="rounded-full transition-all duration-300"
                  style={{
                    width: i === active ? "24px" : "8px",
                    height: "8px",
                    background: i === active
                      ? "linear-gradient(135deg,#FFD700,#FDB931)"
                      : "rgba(255,215,0,0.2)",
                  }}
                />
              ))}
            </div>

            <button
              onClick={handleNext}
              className="w-10 h-10 rounded-full grid place-items-center border transition-all duration-300 hover:scale-110"
              style={{ background: "rgba(255,215,0,0.08)", border: "1px solid rgba(255,215,0,0.2)", color: "rgba(255,215,0,0.7)" }}
            >
              <ChevronRight className="size-5" />
            </button>
          </div>

          {/* Trust strip */}
          <div className={`mt-14 flex flex-wrap items-center justify-center gap-8 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`} style={{ transitionDelay: "500ms" }}>
            {[
              { icon: "⭐", text: "4.9/5 Rating" },
              { icon: "✅", text: "Verified Devotees" },
              { icon: "🙏", text: "5000+ Happy Clients" },
              { icon: "🔱", text: "100% Authentic Puja" },
            ].map(({ icon, text }) => (
              <div key={text} className="flex items-center gap-2 text-sm text-white/40">
                <span>{icon}</span>
                <span>{text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes goldShimmer {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>
    </section>
  );
};
