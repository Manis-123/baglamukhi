import { useEffect, useRef, useState } from "react";
import { Flame, Scale, TrendingUp, Shield, ArrowRight } from "lucide-react";
import { useLang } from "@/i18n/LanguageProvider";
import { Link } from "react-router-dom";

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const SERVICE_META = [
  { icon: Flame,      price: "₹5,100",  color: "#FF6B35", glow: "rgba(255,107,53,0.25)",  badge: "Most Popular" },
  { icon: Scale,      price: "₹7,500",  color: "#FFD700", glow: "rgba(255,215,0,0.25)",   badge: "Powerful" },
  { icon: TrendingUp, price: "₹4,100",  color: "#4ADE80", glow: "rgba(74,222,128,0.25)",  badge: "Growth" },
  { icon: Shield,     price: "₹3,500",  color: "#60A5FA", glow: "rgba(96,165,250,0.25)",  badge: "Protection" },
];

export const Services = () => {
  const { t } = useLang();
  const { ref, inView } = useInView(0.1);

  const services = [
    { ...SERVICE_META[0], title: t("services.s1.title"), desc: t("services.s1.desc") },
    { ...SERVICE_META[1], title: t("services.s2.title"), desc: t("services.s2.desc") },
    { ...SERVICE_META[2], title: t("services.s3.title"), desc: t("services.s3.desc") },
    { ...SERVICE_META[3], title: t("services.s4.title"), desc: t("services.s4.desc") },
  ];

  return (
    <section
      id="services"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-28 overflow-hidden"
      style={{ background: "linear-gradient(180deg,#050505 0%,#08060a 50%,#050505 100%)" }}
    >
      {/* Background grid pattern */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(rgba(255,215,0,0.6) 1px, transparent 1px),
                            linear-gradient(90deg, rgba(255,215,0,0.6) 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Ambient glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[300px] pointer-events-none"
        style={{ background: "radial-gradient(ellipse at center top, rgba(255,215,0,0.05) 0%, transparent 70%)" }} />

      <div className="container relative z-10">
        {/* Section label */}
        <div className={`flex items-center justify-center gap-3 mb-6 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <span className="h-px w-16 bg-gradient-to-r from-transparent to-yellow-500/60" />
          <p className="text-xs tracking-[0.45em] text-yellow-400 font-[Cinzel] uppercase">
            {t("services.kicker")}
          </p>
          <span className="h-px w-16 bg-gradient-to-l from-transparent to-yellow-500/60" />
        </div>

        {/* Heading */}
        <div className={`text-center mb-16 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`} style={{ transitionDelay: "100ms" }}>
          <h2 className="text-3xl md:text-5xl font-bold font-[Cinzel]" style={{ textShadow: "0 0 20px rgba(255,215,0,0.12)" }}>
            {t("services.title.1")}{" "}
            <span style={{
              background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
              backgroundSize: "200% 200%", animation: "goldShimmer 4s ease infinite",
            }}>
              {t("services.title.gold")}
            </span>
          </h2>
          <p className="text-white/40 text-sm mt-3 max-w-md mx-auto">
            Ancient Vedic rituals performed with full Shastriya Vidhi for guaranteed divine blessings
          </p>
        </div>

        {/* Service cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((s, idx) => {
            const Icon = s.icon;
            return (
              <article
                key={s.title}
                className={`group relative rounded-2xl overflow-hidden cursor-pointer transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
                style={{
                  transitionDelay: `${200 + idx * 100}ms`,
                  background: "rgba(10,8,4,0.95)",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}
                onMouseEnter={(e) => {
                  const el = e.currentTarget as HTMLElement;
                  el.style.border = `1px solid ${s.color}55`;
                  el.style.boxShadow = `0 0 40px ${s.glow}, 0 20px 60px rgba(0,0,0,0.6)`;
                  el.style.transform = "translateY(-6px)";
                }}
                onMouseLeave={(e) => {
                  const el = e.currentTarget as HTMLElement;
                  el.style.border = "1px solid rgba(255,255,255,0.06)";
                  el.style.boxShadow = "none";
                  el.style.transform = "translateY(0)";
                }}
              >
                {/* Top color bar */}
                <div className="h-0.5 w-full transition-all duration-500 group-hover:h-[2px]"
                  style={{ background: `linear-gradient(90deg, transparent, ${s.color}, transparent)` }} />

                {/* Badge */}
                <div className="absolute top-4 right-4">
                  <span
                    className="px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wide"
                    style={{ background: `${s.color}22`, color: s.color, border: `1px solid ${s.color}44` }}
                  >
                    {s.badge}
                  </span>
                </div>

                {/* Glow blob */}
                <div
                  className="absolute -top-10 -left-10 w-32 h-32 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"
                  style={{ background: `radial-gradient(circle, ${s.glow} 0%, transparent 70%)` }}
                />

                <div className="p-7">
                  {/* Icon */}
                  <div
                    className="relative w-14 h-14 rounded-2xl grid place-items-center mb-6 transition-all duration-500 group-hover:scale-110"
                    style={{
                      background: `${s.color}15`,
                      border: `1px solid ${s.color}35`,
                    }}
                  >
                    <Icon className="size-6" style={{ color: s.color }} />
                    <div
                      className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                      style={{ boxShadow: `0 0 20px ${s.glow}`, background: `${s.color}08` }}
                    />
                  </div>

                  {/* Title */}
                  <h3 className="text-lg font-bold font-[Cinzel] text-white mb-2 leading-snug">
                    {s.title}
                  </h3>

                  {/* Desc */}
                  <p className="text-sm text-white/45 leading-relaxed mb-6">{s.desc}</p>

                  {/* Price + CTA */}
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs text-white/30 block">Starting from</span>
                      <span className="text-lg font-bold font-[Cinzel]" style={{ color: s.color }}>
                        {s.price}
                      </span>
                    </div>
                    <Link
                      to="/booking"
                      className="flex items-center justify-center w-9 h-9 rounded-full transition-all duration-300 group-hover:scale-110"
                      style={{
                        background: `${s.color}20`,
                        border: `1px solid ${s.color}40`,
                        color: s.color,
                      }}
                    >
                      <ArrowRight className="size-4" />
                    </Link>
                  </div>
                </div>

                {/* Bottom CTA bar — visible on hover */}
                <div
                  className="h-0 overflow-hidden group-hover:h-12 transition-all duration-500 flex items-center justify-center"
                  style={{ background: `${s.color}12`, borderTop: `1px solid ${s.color}25` }}
                >
                  <Link
                    to="/booking"
                    className="text-xs font-semibold tracking-wider uppercase flex items-center gap-1.5"
                    style={{ color: s.color }}
                  >
                    Book This Puja <ArrowRight className="size-3" />
                  </Link>
                </div>
              </article>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className={`text-center mt-14 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`} style={{ transitionDelay: "700ms" }}>
          <Link
            to="/booking"
            className="inline-flex items-center gap-3 px-8 py-3.5 rounded-full text-sm font-semibold transition-all duration-300 hover:scale-105"
            style={{
              background: "linear-gradient(135deg,#FFD700,#FDB931)",
              color: "#000",
              boxShadow: "0 0 30px rgba(255,215,0,0.25)",
            }}
          >
            <Flame className="size-4" />
            सभी सेवाएं बुक करें — Book All Services
            <ArrowRight className="size-4" />
          </Link>
        </div>
      </div>

      <style>{`
        @keyframes goldShimmer {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>
    </section>
  );
};
