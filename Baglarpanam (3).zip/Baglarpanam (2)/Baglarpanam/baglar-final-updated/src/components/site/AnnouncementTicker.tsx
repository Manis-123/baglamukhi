import { useState } from "react";
import { X, Bell } from "lucide-react";

const ANNOUNCEMENTS = [
  "🙏 नवरात्रि महायज्ञ — अभी बुकिंग करें और विशेष आशीर्वाद पाएं",
  "⚡ Special Baglamukhi Havan every Tuesday & Friday — Limited Seats",
  "🌸 Sharad Navratri Booking Now Open — Book Your Puja Today",
  "📿 Online Puja Available for Devotees Across India & Abroad",
  "🔱 Court Case Havan — Assured Victory with Divine Blessings",
  "💛 Donate for Temple Renovation — Earn Divine Merit (Punya)",
];

export const AnnouncementTicker = () => {
  const [visible, setVisible] = useState(true);
  if (!visible) return null;

  const marqueeText = ANNOUNCEMENTS.join("   ✦   ");

  return (
    <div
      className="relative z-[60] overflow-hidden"
      style={{
        background: "linear-gradient(90deg,#7c2d00,#92400e,#78350f,#7c2d00)",
        borderBottom: "1px solid rgba(255,215,0,0.3)",
      }}
    >
      <div className="flex items-center">
        {/* Bell badge */}
        <div
          className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5"
          style={{ background: "rgba(255,215,0,0.15)", borderRight: "1px solid rgba(255,215,0,0.25)" }}
        >
          <Bell className="size-3 text-yellow-400" />
          <span className="text-[10px] font-bold tracking-widest text-yellow-400 font-[Cinzel] uppercase">
            News
          </span>
        </div>

        {/* Scrolling text */}
        <div className="flex-1 overflow-hidden py-1.5 px-2">
          <div className="whitespace-nowrap animate-marquee text-xs text-yellow-100/90 font-medium">
            {marqueeText}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{marqueeText}
          </div>
        </div>

        {/* Close */}
        <button
          onClick={() => setVisible(false)}
          className="flex-shrink-0 p-1.5 mr-1 rounded hover:bg-white/10 transition-colors text-yellow-400/70 hover:text-yellow-400"
        >
          <X className="size-3" />
        </button>
      </div>

      <style>{`
        @keyframes marquee {
          0%   { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          display: inline-block;
          animation: marquee 32s linear infinite;
        }
        .animate-marquee:hover {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  );
};
