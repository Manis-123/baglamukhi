import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Instagram, Phone, MapPin, Mail, ArrowUp, MessageCircle, ExternalLink } from "lucide-react";
import { useLang } from "@/i18n/LanguageProvider";

/* ─── intersection observer hook ─── */
function useInView(threshold = 0.1) {
  const ref = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const NAV_LINKS = [
  { href: "/#about",    labelKey: "nav.about",    external: false },
  { href: "/#services", labelKey: "nav.services", external: false },
  { href: "/booking",   labelKey: "nav.booking",  external: false },
  { href: "/gallery",   labelKey: "nav.gallery",  external: false },
  { href: "/contact",   labelKey: "nav.contact",  external: false },
  { href: "/donation",  labelKey: "nav.donation", external: false },
];

const CONTACT_ITEMS = [
  { icon: Phone,     text: "+91 62657 56977",              href: "tel:+916265756977" },
  { icon: Phone,     text: "+91 94240 72531 (WhatsApp)",   href: "https://wa.me/919424072531" },
  { icon: Mail,      text: "info@baglarpanam.com",         href: "mailto:info@baglarpanam.com" },
  { icon: MapPin,    text: null,                           href: "https://maps.google.com/?q=Nalkheda+Baglamukhi+Temple" },
  { icon: Instagram, text: "@officialyogeshsharma_",       href: "https://www.instagram.com/officialyogeshsharma_" },
];

/* small flickering flame particles */
const FLAMES = Array.from({ length: 6 }, (_, i) => ({
  id: i,
  left: `${10 + i * 16}%`,
  dur: 2.5 + Math.random() * 2,
  delay: Math.random() * 2,
}));

export const Footer = () => {
  const { t } = useLang();
  const { ref, inView } = useInView(0.05);
  const [showTop, setShowTop] = useState(false);

  /* back-to-top button visibility */
  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 600);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  return (
    <>
      {/* ── BACK TO TOP ── */}
      <button
        onClick={scrollTop}
        aria-label="Back to top"
        className="fixed bottom-24 right-5 z-50 size-10 rounded-full grid place-items-center transition-all duration-500"
        style={{
          background: "linear-gradient(135deg,#FFD700,#FDB931)",
          boxShadow: "0 0 20px rgba(255,215,0,0.35)",
          opacity: showTop ? 1 : 0,
          transform: showTop ? "translateY(0) scale(1)" : "translateY(16px) scale(0.8)",
          pointerEvents: showTop ? "auto" : "none",
        }}
      >
        <ArrowUp className="size-4 text-black" />
      </button>

      <footer
        id="contact"
        ref={ref as React.RefObject<HTMLElement>}
        className="relative overflow-hidden"
        style={{ background: "linear-gradient(180deg, #050505 0%, #03020f 100%)" }}
      >
        {/* top divine border */}
        <div className="w-full h-px" style={{ background: "linear-gradient(90deg, transparent, rgba(255,215,0,0.4), transparent)" }} />

        {/* flame particle row */}
        <div className="relative h-8 overflow-hidden pointer-events-none">
          {FLAMES.map(f => (
            <span
              key={f.id}
              className="absolute bottom-0 text-sm select-none"
              style={{
                left: f.left,
                animation: `flameRise ${f.dur}s ${f.delay}s ease-in-out infinite alternate`,
                opacity: 0.5,
              }}
            >
              🔥
            </span>
          ))}
        </div>

        {/* ambient glow top-center */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[200px] pointer-events-none"
          style={{ background: "radial-gradient(ellipse at center top, rgba(255,215,0,0.05) 0%, transparent 70%)" }} />

        {/* ── MAIN GRID ── */}
        <div className="container relative z-10 py-16 grid md:grid-cols-3 gap-12">

          {/* ── Brand col ── */}
          <div
            className={`transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
            style={{ transitionDelay: "0ms" }}
          >
            {/* Om symbol */}
            <div
              className="text-3xl mb-2 select-none"
              style={{
                color: "rgba(255,215,0,0.25)",
                textShadow: "0 0 25px rgba(255,215,0,0.3)",
                animation: "omPulse 4s ease-in-out infinite",
                fontFamily: "Cinzel, serif",
              }}
            >ॐ</div>

            <div
              className="font-[Cinzel] text-2xl font-bold mb-1"
              style={{
                background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
                WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
                backgroundSize: "200% 200%", animation: "goldShimmer 4s ease infinite",
                textShadow: "none",
              }}
            >
              {t("brand.name")}
            </div>

            <p className="text-[10px] text-yellow-400/40 tracking-[0.4em] uppercase mb-4 font-[Cinzel]">
              {t("brand.tagline")}
            </p>

            <div className="h-px mb-4" style={{ background: "linear-gradient(90deg, rgba(255,215,0,0.25), transparent)" }} />

            <p className="text-sm text-white/45 leading-relaxed">{t("footer.about")}</p>

            {/* WhatsApp CTA */}
            <a
              href="https://wa.me/919424072531?text=Jai%20Maa%20Baglamukhi!%20I%20would%20like%20to%20know%20more."
              target="_blank"
              rel="noreferrer"
              className="group mt-6 inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 hover:scale-105"
              style={{
                background: "rgba(37,211,102,0.1)",
                border: "1px solid rgba(37,211,102,0.25)",
                color: "rgba(37,211,102,0.8)",
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLElement).style.background = "rgba(37,211,102,0.15)";
                (e.currentTarget as HTMLElement).style.boxShadow = "0 0 16px rgba(37,211,102,0.15)";
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLElement).style.background = "rgba(37,211,102,0.1)";
                (e.currentTarget as HTMLElement).style.boxShadow = "none";
              }}
            >
              <MessageCircle className="size-4" />
              {t("nav.whatsapp")}
              <span className="group-hover:translate-x-0.5 transition-transform">→</span>
            </a>
          </div>

          {/* ── Contact col ── */}
          <div
            className={`transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
            style={{ transitionDelay: "150ms" }}
          >
            <h4
              className="font-[Cinzel] font-bold mb-6 text-sm tracking-widest uppercase"
              style={{ color: "rgba(255,215,0,0.7)" }}
            >
              {t("footer.contact")}
            </h4>

            <ul className="space-y-4">
              {CONTACT_ITEMS.map(({ icon: Icon, text, href }, i) => (
                <li key={i}>
                  <a
                    href={href}
                    target={href.startsWith("http") ? "_blank" : undefined}
                    rel="noreferrer"
                    className="group flex items-start gap-3 text-sm text-white/45 transition-all duration-300 hover:text-yellow-400"
                  >
                    <span
                      className="mt-0.5 grid place-items-center size-6 rounded-full shrink-0 transition-all duration-300 group-hover:scale-110"
                      style={{
                        background: "rgba(255,215,0,0.08)",
                        border: "1px solid rgba(255,215,0,0.18)",
                      }}
                      onMouseEnter={e => (e.currentTarget.style.boxShadow = "0 0 10px rgba(255,215,0,0.2)")}
                      onMouseLeave={e => (e.currentTarget.style.boxShadow = "none")}
                    >
                      <Icon className="size-3 text-yellow-400/60" />
                    </span>
                    <span className="leading-relaxed">
                      {text ?? t("footer.location")}
                      {href.startsWith("http") && (
                        <ExternalLink className="inline size-2.5 ml-1 opacity-40" />
                      )}
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* ── Quick Links col ── */}
          <div
            className={`transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
            style={{ transitionDelay: "300ms" }}
          >
            <h4
              className="font-[Cinzel] font-bold mb-6 text-sm tracking-widest uppercase"
              style={{ color: "rgba(255,215,0,0.7)" }}
            >
              {t("footer.quick")}
            </h4>

            <ul className="space-y-3">
              {NAV_LINKS.map(({ href, labelKey }) => (
                <li key={href}>
                  <Link
                    to={href}
                    className="group flex items-center gap-2 text-sm text-white/45 transition-all duration-300 hover:text-yellow-400"
                  >
                    <span className="size-1.5 rounded-full bg-yellow-400/30 transition-all duration-300 group-hover:bg-yellow-400 group-hover:scale-150" />
                    {t(labelKey)}
                  </Link>
                </li>
              ))}
            </ul>

            {/* Sacred mantra box */}
            <div
              className="mt-8 rounded-xl p-4 text-center"
              style={{
                background: "rgba(255,215,0,0.03)",
                border: "1px solid rgba(255,215,0,0.1)",
              }}
            >
              <div className="text-yellow-400/50 text-xs font-[Cinzel] italic leading-relaxed">
                🔱 जय माँ बगलामुखी 🔱
              </div>
              <div className="text-yellow-400/30 text-[10px] mt-1 tracking-wider">
                Nalkheda Siddh Peeth
              </div>
            </div>
          </div>
        </div>

        {/* ── BOTTOM BAR ── */}
        <div
          className="relative z-10"
          style={{ borderTop: "1px solid rgba(255,215,0,0.08)" }}
        >
          {/* top gradient line */}
          <div className="h-px" style={{ background: "linear-gradient(90deg, transparent, rgba(255,215,0,0.15), transparent)" }} />

          <div className="container py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-xs text-white/25 text-center sm:text-left">
              {t("footer.copy", { year: new Date().getFullYear() })}
            </p>
            <div className="flex items-center gap-3">
              <span className="text-white/20 text-xs">Made with 🙏 in Nalkheda, MP</span>
              <div className="h-3 w-px bg-white/10" />
              <a
                href="https://www.instagram.com/officialyogeshsharma_"
                target="_blank"
                rel="noreferrer"
                className="text-white/25 hover:text-yellow-400 transition-colors duration-300"
              >
                <Instagram className="size-3.5" />
              </a>
            </div>
          </div>
        </div>

        {/* keyframes */}
        <style>{`
          @keyframes goldShimmer {
            0%   { background-position: 0% 50%; }
            50%  { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
          }
          @keyframes omPulse {
            0%, 100% { opacity: 0.2; transform: scale(1); }
            50%       { opacity: 0.35; transform: scale(1.08); }
          }
          @keyframes flameRise {
            from { transform: translateY(0) scale(1);    opacity: 0.4; }
            to   { transform: translateY(-8px) scale(1.2); opacity: 0.6; }
          }
        `}</style>
      </footer>
    </>
  );
};
