import { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { MessageCircle, Menu, X, ChevronDown, Flame, Clock, Scroll, Landmark } from "lucide-react";
import { useLang } from "@/i18n/LanguageProvider";
import { LanguageSwitcher } from "./LanguageSwitcher";

export const Navbar = () => {
  const { t } = useLang();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => { setMobileOpen(false); setAboutOpen(false); }, [location.pathname]);

  const isHome = location.pathname === "/";

  const scrollToSection = (hash: string) => {
    setMobileOpen(false);
    setAboutOpen(false);
    if (isHome) {
      const el = document.querySelector(hash);
      if (el) el.scrollIntoView({ behavior: "smooth" });
    } else {
      navigate("/" + hash);
    }
  };

  const aboutItems = [
    { label: "Temple",         icon: Landmark, action: () => scrollToSection("#about") },
    { label: "History",        icon: Scroll,   action: () => scrollToSection("#about") },
    { label: "About Temple",   icon: Flame,    action: () => scrollToSection("#about") },
    { label: "Temple Timings", icon: Clock,    action: () => scrollToSection("#about") },
  ];

  const navLinks = [
    { label: t("nav.services"), action: () => scrollToSection("#services") },
    { label: t("nav.booking"),  href: "/booking" },
    { label: t("nav.donation"), href: "/donation" },
    { label: t("nav.gallery"),  href: "/gallery" },
    { label: t("nav.contact"),  href: "/contact" },
  ];

  return (
    <header
      className={`w-full transition-all duration-300 ${
        scrolled
          ? "backdrop-blur-md bg-background/90 border-b border-border/60 shadow-lg shadow-black/30"
          : "backdrop-blur-sm bg-background/70 border-b border-border/40"
      }`}
    >
      <nav className="container flex items-center justify-between h-16 md:h-20 gap-3">

        {/* Brand */}
        <Link to="/" className="flex flex-col leading-tight flex-shrink-0">
          <span className="font-[Cinzel] text-xl md:text-2xl text-gradient-gold font-bold">
            {t("brand.name")}
          </span>
          <span className="text-[10px] md:text-xs text-muted-foreground tracking-widest">
            {t("brand.tagline")}
          </span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden lg:flex items-center gap-6 xl:gap-8">

          {/* ── About dropdown ── */}
          <div
            className="relative"
            onMouseEnter={() => setAboutOpen(true)}
            onMouseLeave={() => setAboutOpen(false)}
          >
            {/* Trigger button */}
            <button
              className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors flex items-center gap-1.5 py-2"
              onClick={() => scrollToSection("#about")}
            >
              {t("nav.about")}
              <ChevronDown
                className="size-3.5 transition-transform duration-300"
                style={{ transform: aboutOpen ? "rotate(180deg)" : "rotate(0deg)" }}
              />
            </button>

            {/* Invisible hover bridge — fills the gap so dropdown doesn't close */}
            <div className="absolute left-0 top-full w-full h-3" />

            {/* Dropdown panel */}
            <div
              className="absolute left-0 top-[calc(100%+10px)] w-64 pointer-events-none"
              style={{
                opacity: aboutOpen ? 1 : 0,
                transform: aboutOpen ? "translateY(0)" : "translateY(-8px)",
                transition: "opacity 0.2s ease, transform 0.2s ease",
                pointerEvents: aboutOpen ? "auto" : "none",
                zIndex: 200,
              }}
            >
              {/* Top arrow */}
              <div
                className="absolute -top-2 left-6 w-4 h-2 overflow-hidden"
              >
                <div
                  className="w-3 h-3 rotate-45 mx-auto mt-1"
                  style={{
                    background: "#0f0a02",
                    border: "1px solid rgba(255,215,0,0.25)",
                  }}
                />
              </div>

              {/* Panel */}
              <div
                className="rounded-2xl overflow-hidden shadow-2xl"
                style={{
                  background: "linear-gradient(135deg, #0f0a02 0%, #0a0601 100%)",
                  border: "1px solid rgba(255,215,0,0.2)",
                  boxShadow: "0 20px 60px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,215,0,0.05)",
                }}
              >
                {/* Panel header */}
                <div
                  className="px-4 py-3 border-b"
                  style={{ borderColor: "rgba(255,215,0,0.1)", background: "rgba(255,215,0,0.04)" }}
                >
                  <p className="text-[10px] tracking-[0.4em] text-yellow-400/60 font-[Cinzel] uppercase">
                    Baglamukhi Siddh Peeth
                  </p>
                </div>

                {/* Items */}
                <div className="p-2">
                  {aboutItems.map((item, i) => {
                    const Icon = item.icon;
                    return (
                      <button
                        key={i}
                        onClick={item.action}
                        className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-white/70 hover:text-yellow-400 hover:bg-yellow-400/8 transition-all duration-150 group text-left"
                      >
                        <span
                          className="w-7 h-7 rounded-lg grid place-items-center flex-shrink-0 transition-all duration-200 group-hover:scale-110"
                          style={{
                            background: "rgba(255,215,0,0.08)",
                            border: "1px solid rgba(255,215,0,0.15)",
                          }}
                        >
                          <Icon className="size-3.5 text-yellow-400/60 group-hover:text-yellow-400 transition-colors" />
                        </span>
                        <span className="font-medium">{item.label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Panel footer */}
                <div
                  className="px-4 py-2.5 border-t"
                  style={{ borderColor: "rgba(255,215,0,0.08)" }}
                >
                  <button
                    onClick={() => scrollToSection("#about")}
                    className="text-xs text-yellow-400/50 hover:text-yellow-400 transition-colors flex items-center gap-1"
                  >
                    View Full About →
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Other nav links */}
          {navLinks.map((link) =>
            link.href ? (
              <Link
                key={link.label}
                to={link.href}
                className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors relative group py-2"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 h-px w-0 bg-yellow-400 group-hover:w-full transition-all duration-300" />
              </Link>
            ) : (
              <button
                key={link.label}
                onClick={link.action}
                className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors relative group py-2"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 h-px w-0 bg-yellow-400 group-hover:w-full transition-all duration-300" />
              </button>
            )
          )}
        </div>

        {/* Right side */}
        <div className="flex items-center gap-2">
          <LanguageSwitcher />
          <Button variant="hero" size="sm" asChild className="hidden sm:inline-flex">
            <a href="https://wa.me/919424072531" target="_blank" rel="noreferrer">
              <MessageCircle className="size-4" />
              <span className="hidden md:inline">{t("nav.whatsapp")}</span>
            </a>
          </Button>

          {/* Hamburger */}
          <button
            onClick={() => setMobileOpen((v) => !v)}
            className="lg:hidden p-2 rounded-lg border border-yellow-400/20 text-yellow-400 hover:bg-yellow-400/10 transition-colors"
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </nav>

      {/* ── Mobile drawer ── */}
      <div
        className="lg:hidden fixed inset-0 z-[200] transition-all duration-300"
        style={{
          opacity: mobileOpen ? 1 : 0,
          pointerEvents: mobileOpen ? "auto" : "none",
          background: "rgba(0,0,0,0.6)",
          backdropFilter: "blur(4px)",
        }}
        onClick={() => setMobileOpen(false)}
      >
        <div
          className="absolute inset-x-0 top-0 border-b overflow-y-auto max-h-screen"
          style={{
            background: "linear-gradient(180deg,#0c0700 0%,#050505 100%)",
            borderColor: "rgba(255,215,0,0.15)",
            transform: mobileOpen ? "translateY(0)" : "translateY(-8px)",
            transition: "transform 0.3s ease",
          }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* About section */}
          <div className="px-4 pt-4 pb-3">
            <p className="text-[10px] tracking-widest text-yellow-500/50 font-[Cinzel] uppercase mb-2 px-1">
              {t("nav.about")}
            </p>
            <div className="grid grid-cols-2 gap-1">
              {aboutItems.map((item, i) => {
                const Icon = item.icon;
                return (
                  <button
                    key={i}
                    onClick={item.action}
                    className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm text-white/70 hover:text-yellow-400 hover:bg-white/5 transition-all text-left"
                  >
                    <Icon className="size-3.5 text-yellow-400/50 flex-shrink-0" />
                    {item.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="h-px mx-4" style={{ background: "rgba(255,215,0,0.1)" }} />

          {/* Main links */}
          <div className="px-4 py-2 space-y-0.5">
            {navLinks.map((link) =>
              link.href ? (
                <Link
                  key={link.label}
                  to={link.href}
                  className="flex items-center justify-between px-3 py-3 rounded-xl text-sm font-medium text-white/80 hover:text-yellow-400 hover:bg-white/5 transition-all"
                >
                  {link.label}
                  <span className="text-yellow-400/30 text-xs">→</span>
                </Link>
              ) : (
                <button
                  key={link.label}
                  onClick={link.action}
                  className="w-full flex items-center justify-between px-3 py-3 rounded-xl text-sm font-medium text-white/80 hover:text-yellow-400 hover:bg-white/5 transition-all"
                >
                  {link.label}
                  <span className="text-yellow-400/30 text-xs">→</span>
                </button>
              )
            )}
          </div>

          {/* WhatsApp CTA */}
          <div className="px-4 pb-5 pt-2">
            <a
              href="https://wa.me/919424072531"
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 rounded-xl text-sm font-semibold transition-all hover:opacity-90"
              style={{ background: "linear-gradient(135deg,#FFD700,#FDB931)", color: "#000" }}
            >
              <MessageCircle className="size-4" />
              {t("nav.whatsapp")}
            </a>
          </div>
        </div>
      </div>
    </header>
  );
};
