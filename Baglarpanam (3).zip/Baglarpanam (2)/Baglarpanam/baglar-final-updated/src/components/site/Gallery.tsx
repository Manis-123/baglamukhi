import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { useLang } from "@/i18n/LanguageProvider";
import { X, ChevronLeft, ChevronRight, ZoomIn, ArrowRight } from "lucide-react";

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

/* Preview photos shown on homepage — from public/gallery/ */
const PREVIEW_PHOTOS = [
  { src: "/gallery/photo-01.jpg", caption: "माँ बगलामुखी दर्शन" },
  { src: "/gallery/photo-02.jpg", caption: "हवन यज्ञ" },
  { src: "/gallery/photo-03.jpg", caption: "मंदिर परिसर" },
  { src: "/gallery/photo-04.jpg", caption: "श्री यंत्र" },
  { src: "/gallery/photo-05.jpg", caption: "नवरात्रि उत्सव" },
  { src: "/gallery/photo-06.jpg", caption: "अग्नि हवन" },
];

export const Gallery = () => {
  const { t } = useLang();
  const { ref, inView } = useInView(0.1);

  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const openLightbox = (index: number) => {
    setCurrentIndex(index);
    setLightboxOpen(true);
    document.body.style.overflow = "hidden";
  };
  const closeLightbox = () => {
    setLightboxOpen(false);
    document.body.style.overflow = "";
  };
  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % PREVIEW_PHOTOS.length);
  };
  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev - 1 + PREVIEW_PHOTOS.length) % PREVIEW_PHOTOS.length);
  };

  return (
    <section
      id="gallery"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-28 overflow-hidden"
      style={{ background: "linear-gradient(180deg,#0a0700 0%,#050505 50%,#0a0700 100%)" }}
    >
      {/* ambient glows */}
      <div className="absolute right-0 top-1/4 w-[500px] h-[500px] pointer-events-none"
        style={{ background: "radial-gradient(ellipse at right, rgba(255,215,0,0.04) 0%, transparent 60%)" }} />
      <div className="absolute left-0 bottom-1/4 w-[400px] h-[400px] pointer-events-none"
        style={{ background: "radial-gradient(circle at left, rgba(255,150,0,0.03) 0%, transparent 60%)" }} />

      <div className="container relative z-10">
        {/* Section label */}
        <div className={`flex items-center justify-center gap-3 mb-6 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <span className="h-px w-16 bg-gradient-to-r from-transparent to-yellow-500/60" />
          <p className="text-xs tracking-[0.45em] text-yellow-400 font-[Cinzel] uppercase">
            {t("gallery.kicker")}
          </p>
          <span className="h-px w-16 bg-gradient-to-l from-transparent to-yellow-500/60" />
        </div>

        {/* Heading */}
        <div
          className={`text-center mb-14 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
          style={{ transitionDelay: "100ms" }}
        >
          <h2
            className="text-3xl md:text-5xl font-bold font-[Cinzel]"
            style={{ textShadow: "0 0 20px rgba(255,215,0,0.12)" }}
          >
            {t("gallery.title.1")}{" "}
            <span style={{
              background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
              backgroundSize: "200% 200%", animation: "goldShimmer 4s ease infinite",
            }}>
              {t("gallery.title.gold")}
            </span>
          </h2>
          <p className="text-white/40 text-sm mt-3 max-w-md mx-auto">
            Sacred moments captured at Baglamukhi Siddh Peeth, Nalkheda
          </p>
        </div>

        {/* Photo grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {PREVIEW_PHOTOS.map((photo, idx) => (
            <div
              key={idx}
              onClick={() => openLightbox(idx)}
              className={`group relative aspect-[4/5] md:aspect-square rounded-2xl overflow-hidden cursor-pointer transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
              style={{
                transitionDelay: `${200 + idx * 100}ms`,
                background: "rgba(20,16,8,0.9)",
                border: "1px solid rgba(255,215,0,0.15)",
                boxShadow: "0 4px 20px rgba(0,0,0,0.4)",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow = "0 8px 30px rgba(255,215,0,0.15)";
                (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,215,0,0.4)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 20px rgba(0,0,0,0.4)";
                (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,215,0,0.15)";
              }}
            >
              <img
                src={photo.src}
                alt={photo.caption}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div
                  className="w-12 h-12 rounded-full grid place-items-center scale-75 group-hover:scale-100 transition-transform duration-500"
                  style={{
                    background: "rgba(255,215,0,0.15)",
                    border: "1px solid rgba(255,215,0,0.4)",
                    backdropFilter: "blur(4px)",
                  }}
                >
                  <ZoomIn className="size-5 text-yellow-400" />
                </div>
                <span className="text-xs text-white/80 font-medium px-2 text-center">{photo.caption}</span>
              </div>
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div
          className={`flex justify-center mt-12 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
          style={{ transitionDelay: "800ms" }}
        >
          <Link
            to="/gallery"
            className="group inline-flex items-center gap-3 px-8 py-3.5 rounded-full font-semibold text-sm transition-all duration-300"
            style={{
              background: "rgba(255,215,0,0.1)",
              border: "1px solid rgba(255,215,0,0.3)",
              color: "rgba(255,215,0,0.9)",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "linear-gradient(135deg,#FFD700,#FDB931)";
              (e.currentTarget as HTMLElement).style.color = "#000";
              (e.currentTarget as HTMLElement).style.boxShadow = "0 0 25px rgba(255,215,0,0.25)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "rgba(255,215,0,0.1)";
              (e.currentTarget as HTMLElement).style.color = "rgba(255,215,0,0.9)";
              (e.currentTarget as HTMLElement).style.boxShadow = "none";
            }}
          >
            पूरी गैलरी देखें — View Full Gallery
            <ArrowRight className="size-4 group-hover:translate-x-1 transition-transform duration-300" />
          </Link>
        </div>
      </div>

      {/* Lightbox */}
      {lightboxOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8"
          style={{ background: "rgba(0,0,0,0.96)", backdropFilter: "blur(10px)" }}
          onClick={closeLightbox}
        >
          <button onClick={closeLightbox} className="absolute top-6 right-6 z-50 p-2 rounded-full border border-white/20 bg-white/5 hover:bg-white/10 hover:border-yellow-400/50 transition-colors text-white">
            <X className="size-6" />
          </button>
          <button onClick={prevImage} className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 z-50 p-3 rounded-full border border-white/20 bg-white/5 hover:bg-white/10 hover:border-yellow-400/50 transition-colors text-white hidden sm:block">
            <ChevronLeft className="size-8" />
          </button>
          <div
            className="relative w-full max-w-5xl flex flex-col items-center justify-center gap-3"
            onClick={(e) => e.stopPropagation()}
            style={{ animation: "scaleIn 0.3s ease-out" }}
          >
            <img
              src={PREVIEW_PHOTOS[currentIndex].src}
              alt={PREVIEW_PHOTOS[currentIndex].caption}
              className="max-w-full max-h-[80vh] object-contain rounded-lg"
              style={{ boxShadow: "0 0 50px rgba(255,215,0,0.15)", border: "1px solid rgba(255,215,0,0.1)" }}
            />
            <p className="text-white/60 text-sm">{PREVIEW_PHOTOS[currentIndex].caption}</p>
          </div>
          <button onClick={nextImage} className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 z-50 p-3 rounded-full border border-white/20 bg-white/5 hover:bg-white/10 hover:border-yellow-400/50 transition-colors text-white hidden sm:block">
            <ChevronRight className="size-8" />
          </button>
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-4 sm:hidden z-50">
            <button onClick={prevImage} className="p-3 rounded-full bg-black/50 border border-white/20 text-white"><ChevronLeft className="size-6" /></button>
            <span className="text-white/60 font-[Cinzel] tracking-widest">{currentIndex + 1} / {PREVIEW_PHOTOS.length}</span>
            <button onClick={nextImage} className="p-3 rounded-full bg-black/50 border border-white/20 text-white"><ChevronRight className="size-6" /></button>
          </div>
        </div>
      )}

      <style>{`
        @keyframes goldShimmer {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.95); }
          to   { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </section>
  );
};
