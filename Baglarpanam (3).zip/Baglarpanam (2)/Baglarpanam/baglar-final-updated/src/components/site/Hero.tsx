import { Button } from "@/components/ui/button";
import { ArrowRight, Calendar, ChevronDown, MessageCircle } from "lucide-react";
import { Link } from "react-router-dom";
import hero from "@/assets/hero-baglamukhi.jpg";
import { useLang } from "@/i18n/LanguageProvider";
import { useEffect, useRef, useState, useCallback } from "react";

/* ─── animated counter hook ─── */
function useCounter(target: number, duration = 2000, start = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    const step = (ts: number) => {
      if (!startTime) startTime = ts;
      const progress = Math.min((ts - startTime) / duration, 1);
      setCount(Math.floor(progress * target));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [start, target, duration]);
  return count;
}

/* ─── particle data ─── */
const PARTICLES = Array.from({ length: 18 }, (_, i) => ({
  id: i,
  left: `${Math.random() * 100}%`,
  top: `${Math.random() * 100}%`,
  size: Math.random() * 3 + 1,
  dur: Math.random() * 6 + 4,
  delay: Math.random() * 5,
}));

export const Hero = () => {
  const { t } = useLang();

  /* ── parallax ── */
  const imgRef = useRef<HTMLImageElement>(null);
  const sectionRef = useRef<HTMLElement>(null);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!imgRef.current || !sectionRef.current) return;
    const { width, height, left, top } =
      sectionRef.current.getBoundingClientRect();
    const x = ((e.clientX - left) / width - 0.5) * 14;
    const y = ((e.clientY - top) / height - 0.5) * 10;
    imgRef.current.style.transform = `translate(${x}px, ${y}px) scale(1.06)`;
  }, []);

  const resetParallax = useCallback(() => {
    if (imgRef.current)
      imgRef.current.style.transform = "translate(0,0) scale(1.06)";
  }, []);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    el.addEventListener("mousemove", handleMouseMove);
    el.addEventListener("mouseleave", resetParallax);
    return () => {
      el.removeEventListener("mousemove", handleMouseMove);
      el.removeEventListener("mouseleave", resetParallax);
    };
  }, [handleMouseMove, resetParallax]);

  /* ── entrance + counter trigger ── */
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  const c1 = useCounter(15, 1800, visible);
  const c2 = useCounter(5000, 2200, visible);
  const c3 = useCounter(21, 1400, visible);

  const rawStats = [
    { k: t("hero.stat1.k"), v: t("hero.stat1.v"), count: c1, suffix: "+" },
    { k: t("hero.stat2.k"), v: t("hero.stat2.v"), count: c2, suffix: "+" },
    { k: t("hero.stat3.k"), v: t("hero.stat3.v"), count: c3, suffix: "" },
  ];

  /* ── scroll hint ── */
  const scrollDown = () =>
    document.getElementById("about")?.scrollIntoView({ behavior: "smooth" });

  return (
    <section
      ref={sectionRef}
      id="home"
      className="relative min-h-[100svh] flex flex-col items-center justify-center overflow-hidden"
      style={{ background: "#050505" }}
    >
      {/* ── background image with parallax ── */}
      <img
        ref={imgRef}
        src={hero}
        alt="Goddess Baglamukhi Devi"
        className="absolute inset-0 w-[calc(100%+14px)] h-[calc(100%+10px)] -left-[7px] -top-[5px] object-cover"
        style={{
          objectPosition: "center top",
          transform: "scale(1.06)",
          transition: "transform 0.12s ease-out",
          willChange: "transform",
        }}
      />

      {/* ── dark gradient overlay ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "linear-gradient(to bottom, rgba(0,0,0,0.78) 0%, rgba(0,0,0,0.52) 35%, rgba(0,0,0,0.68) 65%, rgba(0,0,0,0.96) 100%)",
        }}
      />

      {/* ── radial golden vignette ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 70% 60% at 50% 50%, rgba(255,215,0,0.04) 0%, transparent 70%)",
        }}
      />

      {/* ── floating gold particles ── */}
      {PARTICLES.map((p) => (
        <span
          key={p.id}
          className="absolute rounded-full bg-yellow-400/30 pointer-events-none"
          style={{
            left: p.left,
            top: p.top,
            width: p.size,
            height: p.size,
            animation: `floatParticle ${p.dur}s ${p.delay}s ease-in-out infinite alternate`,
          }}
        />
      ))}

      {/* ── Om / sacred symbol glow ── */}
      <div
        className="absolute top-28 left-1/2 -translate-x-1/2 pointer-events-none select-none"
        style={{
          fontSize: "clamp(2.5rem, 6vw, 4rem)",
          color: "rgba(255,215,0,0.18)",
          textShadow: "0 0 40px rgba(255,215,0,0.35)",
          animation: "omPulse 4s ease-in-out infinite",
          fontFamily: "Cinzel, serif",
        }}
      >
        ॐ
      </div>

      {/* ── MAIN CONTENT ── */}
      <div className="relative container text-center max-w-3xl pt-44 pb-28 px-4 flex flex-col items-center">

        {/* badge */}
        <p
          className={`inline-block text-xs md:text-sm tracking-[0.4em] text-yellow-400 mb-6 transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
          style={{ transitionDelay: "0ms", fontFamily: "Cinzel, serif" }}
        >
          ✦ {t("hero.badge")} ✦
        </p>

        {/* main heading */}
        <h1
          className={`font-bold leading-tight transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
          style={{
            fontSize: "clamp(2.2rem, 5.5vw, 3.8rem)",
            transitionDelay: "150ms",
            fontFamily: "Cinzel, serif",
            background: "linear-gradient(135deg, #FFD700 0%, #FDB931 40%, #FFE566 60%, #FFD700 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
            filter: "drop-shadow(0 0 18px rgba(255,215,0,0.4))",
            backgroundSize: "200% 200%",
            animation: "goldShimmer 4s ease infinite",
          }}
        >
          {t("hero.title.1")} {t("hero.title.and")}<br />
          {t("hero.title.2")}
        </h1>

        {/* subtitle */}
        <p
          className={`mt-6 text-lg md:text-xl text-white/85 transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
          style={{ transitionDelay: "280ms", fontFamily: "Cinzel, serif" }}
        >
          {t("hero.subtitle")}
        </p>

        {/* sub-stats line */}
        <p
          className={`mt-3 text-sm md:text-base text-white/55 transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
          style={{ transitionDelay: "380ms" }}
        >
          {t("hero.stats")}
        </p>

        {/* ── animated stat cards ── */}
        <div
          className={`mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl w-full mx-auto transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          style={{ transitionDelay: "480ms" }}
        >
          {rawStats.map((s, i) => (
            <div
              key={i}
              className="group relative border border-yellow-500/25 bg-black/40 backdrop-blur-md rounded-xl px-4 py-4 text-center overflow-hidden cursor-default hover:border-yellow-400/60 hover:bg-black/60 transition-all duration-300"
            >
              {/* hover glow */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none rounded-xl"
                style={{ background: "radial-gradient(ellipse at center, rgba(255,215,0,0.08) 0%, transparent 70%)" }} />

              <div className="text-2xl font-bold text-yellow-400 font-[Cinzel] drop-shadow-[0_0_8px_rgba(255,215,0,0.5)]">
                {s.count.toLocaleString()}{s.suffix}
              </div>
              <div className="text-[11px] uppercase tracking-widest text-yellow-400/70 mt-1">
                {s.k}
              </div>
              <div className="text-xs text-white/60 mt-1">{s.v}</div>
            </div>
          ))}
        </div>

        {/* ── CTA buttons ── */}
        <div
          className={`mt-10 flex flex-col sm:flex-row gap-4 justify-center transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          style={{ transitionDelay: "580ms" }}
        >
          {/* Book Puja */}
          <Button variant="hero" size="xl" asChild>
            <Link
              to="/booking"
              className="group relative overflow-hidden"
            >
              <span className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300 rounded-xl" />
              <Calendar className="size-5 relative z-10" />
              <span className="relative z-10">{t("hero.cta.book")}</span>
            </Link>
          </Button>

          {/* WhatsApp consult */}
          <Button variant="outlineGold" size="xl" asChild>
            <a
              href="https://wa.me/919424072531?text=Jai%20Maa%20Baglamukhi!%20I%20would%20like%20to%20know%20more%20about%20puja%20bookings."
              target="_blank"
              rel="noreferrer"
              className="group relative overflow-hidden"
            >
              <span className="absolute inset-0 bg-yellow-400/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300 rounded-xl" />
              <MessageCircle className="size-5 relative z-10" />
              <span className="relative z-10">{t("hero.cta.consult")}</span>
              <ArrowRight className="size-5 relative z-10 group-hover:translate-x-1 transition-transform duration-300" />
            </a>
          </Button>
        </div>
      </div>

      {/* ── scroll chevron ── */}
      <button
        onClick={scrollDown}
        aria-label="Scroll down"
        className={`absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 text-yellow-400/60 hover:text-yellow-400 transition-all duration-700 cursor-pointer group ${visible ? "opacity-100" : "opacity-0"}`}
        style={{ transitionDelay: "780ms", background: "none", border: "none" }}
      >
        <span className="text-[10px] tracking-[0.3em] uppercase font-[Cinzel] mb-1">Scroll</span>
        <ChevronDown
          className="size-5 animate-bounce"
          style={{ animationDuration: "1.6s" }}
        />
      </button>

      {/* ── Bottom wave divider ── */}
      <div className="absolute bottom-0 inset-x-0 pointer-events-none">
        <div className="h-px w-full" style={{ background: "linear-gradient(90deg, transparent, rgba(255,215,0,0.3), transparent)" }} />
        <svg viewBox="0 0 1440 40" className="w-full" style={{ display: "block", fill: "#050505" }}>
          <path d="M0,20 C360,40 1080,0 1440,20 L1440,40 L0,40 Z" />
        </svg>
      </div>

      {/* ── keyframe styles injected ── */}
      <style>{`
        @keyframes floatParticle {
          from { transform: translateY(0px) scale(1); opacity: 0.3; }
          to   { transform: translateY(-24px) scale(1.4); opacity: 0; }
        }
        @keyframes omPulse {
          0%, 100% { opacity: 0.15; transform: translateX(-50%) scale(1); }
          50%       { opacity: 0.32; transform: translateX(-50%) scale(1.08); }
        }
        @keyframes goldShimmer {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>
    </section>
  );
};
