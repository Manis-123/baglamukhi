import { AnnouncementTicker } from "./AnnouncementTicker";
import { Navbar } from "./Navbar";

export const SiteHeader = () => (
  <div className="fixed top-0 inset-x-0 z-50">
    <AnnouncementTicker />
    <Navbar />
  </div>
);
