import { useEffect } from "react";
import { Link } from "react-router-dom";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Donation } from "@/components/site/Donation";
import { Footer } from "@/components/site/Footer";
import { WhatsAppFab } from "@/components/site/WhatsAppFab";
import { Heart, Home, ChevronRight, HandHeart, Sparkles, ShieldCheck } from "lucide-react";

const DonationPage = () => {
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  return (
    <main className="min-h-screen" style={{ background: "#050505" }}>
      <SiteHeader />

      {/* Page Hero Banner */}
      <section
        className="relative pt-24 md:pt-32 pb-16 overflow-hidden"
        style={{ background: "linear-gradient(180deg,#0d0800 0%,#050505 100%)" }}
      >
        {/* Glow effects */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse 80% 60% at 50% 0%, rgba(255,215,0,0.06) 0%, transparent 70%)",
          }}
        />
        <div
          className="absolute left-0 top-0 w-[300px] h-[300px] pointer-events-none"
          style={{
            background:
              "radial-gradient(circle at 0% 0%, rgba(255,100,0,0.04) 0%, transparent 60%)",
          }}
        />
        <div
          className="absolute right-0 bottom-0 w-[300px] h-[300px] pointer-events-none"
          style={{
            background:
              "radial-gradient(circle at 100% 100%, rgba(255,215,0,0.04) 0%, transparent 60%)",
          }}
        />

        <div className="container relative z-10 text-center">
          {/* Breadcrumb */}
          <nav className="flex items-center justify-center gap-1.5 text-xs text-white/40 mb-8">
            <Link to="/" className="flex items-center gap-1 hover:text-yellow-400 transition-colors">
              <Home className="size-3" /> Home
            </Link>
            <ChevronRight className="size-3" />
            <span className="text-yellow-400">Donation</span>
          </nav>

          {/* Kicker */}
          <div className="flex items-center justify-center gap-3 mb-5">
            <span className="h-px w-14 bg-gradient-to-r from-transparent to-yellow-500/60" />
            <Heart className="size-4 text-yellow-400 fill-yellow-400/30" />
            <span className="text-xs tracking-[0.45em] text-yellow-400 font-[Cinzel] uppercase">
              दान — Sacred Offering
            </span>
            <Heart className="size-4 text-yellow-400 fill-yellow-400/30" />
            <span className="h-px w-14 bg-gradient-to-l from-transparent to-yellow-500/60" />
          </div>

          {/* Title */}
          <h1
            className="text-4xl md:text-6xl font-bold font-[Cinzel] mb-4"
            style={{ textShadow: "0 0 30px rgba(255,215,0,0.1)" }}
          >
            दान{" "}
            <span
              style={{
                background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
                backgroundSize: "200% 200%",
                animation: "goldShimmer 4s ease infinite",
              }}
            >
              करें
            </span>
          </h1>
          <p className="text-white/50 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Your generous contribution supports divine rituals, temple renovation, and the propagation of Vedic wisdom. Every donation earns sacred merit (Punya).
          </p>

          {/* Info pills */}
          <div className="flex flex-wrap items-center justify-center gap-3 mt-8">
            {[
              { icon: ShieldCheck, text: "80G Tax Exemption" },
              { icon: HandHeart,   text: "Transparent Use" },
              { icon: Sparkles,    text: "Divine Punya" },
              { icon: Heart,       text: "Anonymous Option" },
            ].map(({ icon: Icon, text }) => (
              <span
                key={text}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-medium"
                style={{
                  background: "rgba(255,215,0,0.08)",
                  border: "1px solid rgba(255,215,0,0.2)",
                  color: "rgba(255,215,0,0.8)",
                }}
              >
                <Icon className="size-3" />
                {text}
              </span>
            ))}
          </div>

          {/* Punya quote */}
          <div
            className="mt-10 mx-auto max-w-lg py-4 px-6 rounded-2xl"
            style={{
              background: "rgba(255,215,0,0.04)",
              border: "1px solid rgba(255,215,0,0.12)",
            }}
          >
            <p className="text-yellow-400/70 font-[Cinzel] text-sm italic">
              "दानं परमं बलम्" — Charity is the greatest strength
            </p>
            <p className="text-white/30 text-xs mt-1">— Mahabharat</p>
          </div>
        </div>
      </section>

      {/* Donation form */}
      <Donation />

      <Footer />
      <WhatsAppFab />

      <style>{`
        @keyframes goldShimmer {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>
    </main>
  );
};

export default DonationPage;
