import { useState, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Footer } from "@/components/site/Footer";
import { WhatsAppFab } from "@/components/site/WhatsAppFab";
import { X, ChevronLeft, ChevronRight, ZoomIn, Home, Images } from "lucide-react";

/* ─── Photo data — place your images in /public/gallery/ ─── */
interface Photo {
  src: string;
  caption: string;
  category: string;
}

const PHOTOS: Photo[] = [
  { src: "/gallery/photo-01.jpg", caption: "माँ बगलामुखी दर्शन", category: "Darshan" },
  { src: "/gallery/photo-02.jpg", caption: "हवन यज्ञ", category: "Havan" },
  { src: "/gallery/photo-03.jpg", caption: "मंदिर परिसर", category: "Temple" },
  { src: "/gallery/photo-04.jpg", caption: "श्री यंत्र", category: "Yantra" },
  { src: "/gallery/photo-05.jpg", caption: "नवरात्रि उत्सव", category: "Festival" },
  { src: "/gallery/photo-06.jpg", caption: "अग्नि हवन", category: "Havan" },
  { src: "/gallery/photo-07.jpg", caption: "मंदिर प्रवेश", category: "Temple" },
  { src: "/gallery/photo-08.jpg", caption: "यंत्र पूजन", category: "Yantra" },
];

const CATEGORIES = ["All", ...Array.from(new Set(PHOTOS.map((p) => p.category)))];

export const GalleryPage = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const filtered = activeCategory === "All"
    ? PHOTOS
    : PHOTOS.filter((p) => p.category === activeCategory);

  const openLightbox = (idx: number) => {
    setLightboxIndex(idx);
    document.body.style.overflow = "hidden";
  };
  const closeLightbox = useCallback(() => {
    setLightboxIndex(null);
    document.body.style.overflow = "";
  }, []);
  const prevPhoto = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    setLightboxIndex((i) => (i !== null ? (i - 1 + filtered.length) % filtered.length : 0));
  }, [filtered.length]);
  const nextPhoto = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    setLightboxIndex((i) => (i !== null ? (i + 1) % filtered.length : 0));
  }, [filtered.length]);

  // Keyboard navigation
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (lightboxIndex === null) return;
      if (e.key === "ArrowLeft") setLightboxIndex((i) => (i! - 1 + filtered.length) % filtered.length);
      if (e.key === "ArrowRight") setLightboxIndex((i) => (i! + 1) % filtered.length);
      if (e.key === "Escape") closeLightbox();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lightboxIndex, filtered.length, closeLightbox]);

  useEffect(() => { window.scrollTo({ top: 0, behavior: "smooth" }); }, []);

  return (
    <main className="min-h-screen" style={{ background: "#050505" }}>
      <SiteHeader />

      {/* Page Banner */}
      <section
        className="relative pt-24 md:pt-32 pb-16 overflow-hidden"
        style={{ background: "linear-gradient(180deg,#0d0800 0%,#050505 100%)" }}
      >
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse 80% 60% at 50% 0%, rgba(255,215,0,0.06) 0%, transparent 70%)",
          }}
        />

        <div className="container relative z-10 text-center">
          {/* Breadcrumb */}
          <nav className="flex items-center justify-center gap-1.5 text-xs text-white/40 mb-8">
            <Link to="/" className="flex items-center gap-1 hover:text-yellow-400 transition-colors">
              <Home className="size-3" /> Home
            </Link>
            <ChevronRight className="size-3" />
            <span className="text-yellow-400">Gallery</span>
          </nav>

          {/* Kicker */}
          <div className="flex items-center justify-center gap-3 mb-5">
            <span className="h-px w-14 bg-gradient-to-r from-transparent to-yellow-500/60" />
            <Images className="size-4 text-yellow-400" />
            <span className="text-xs tracking-[0.45em] text-yellow-400 font-[Cinzel] uppercase">
              Divine Moments
            </span>
            <Images className="size-4 text-yellow-400" />
            <span className="h-px w-14 bg-gradient-to-l from-transparent to-yellow-500/60" />
          </div>

          <h1
            className="text-4xl md:text-6xl font-bold font-[Cinzel] mb-4"
            style={{ textShadow: "0 0 30px rgba(255,215,0,0.1)" }}
          >
            फोटो{" "}
            <span
              style={{
                background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
                backgroundSize: "200% 200%",
                animation: "goldShimmer 4s ease infinite",
              }}
            >
              गैलरी
            </span>
          </h1>
          <p className="text-white/50 text-sm md:text-base max-w-lg mx-auto leading-relaxed">
            Sacred moments from rituals, havans, and divine festivals at Baglamukhi Siddh Peeth, Nalkheda.
          </p>
        </div>
      </section>

      {/* Gallery Content */}
      <section className="py-12 pb-28">
        <div className="container">

          {/* Category filter tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className="px-5 py-2 rounded-full text-sm font-medium transition-all duration-300"
                style={
                  activeCategory === cat
                    ? {
                        background: "linear-gradient(135deg,#FFD700,#FDB931)",
                        color: "#000",
                        boxShadow: "0 0 20px rgba(255,215,0,0.25)",
                      }
                    : {
                        background: "rgba(255,215,0,0.06)",
                        border: "1px solid rgba(255,215,0,0.2)",
                        color: "rgba(255,255,255,0.6)",
                      }
                }
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Photo count */}
          <p className="text-center text-xs text-white/30 mb-8 tracking-widest">
            {filtered.length} PHOTO{filtered.length !== 1 ? "S" : ""}
          </p>

          {/* Masonry-style grid */}
          <div className="columns-2 md:columns-3 lg:columns-4 gap-4 space-y-4">
            {filtered.map((photo, idx) => (
              <div
                key={`${activeCategory}-${idx}`}
                onClick={() => openLightbox(idx)}
                className="group relative break-inside-avoid rounded-2xl overflow-hidden cursor-pointer"
                style={{
                  border: "1px solid rgba(255,215,0,0.12)",
                  boxShadow: "0 4px 20px rgba(0,0,0,0.5)",
                  background: "#0a0700",
                  animation: `fadeInUp 0.4s ease both`,
                  animationDelay: `${idx * 60}ms`,
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,215,0,0.4)";
                  (e.currentTarget as HTMLElement).style.boxShadow = "0 8px 30px rgba(255,215,0,0.12)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,215,0,0.12)";
                  (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 20px rgba(0,0,0,0.5)";
                }}
              >
                <img
                  src={photo.src}
                  alt={photo.caption}
                  loading="lazy"
                  className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  style={{ display: "block" }}
                />

                {/* Hover overlay */}
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 gap-2">
                  <div
                    className="w-10 h-10 rounded-full grid place-items-center"
                    style={{
                      background: "rgba(255,215,0,0.15)",
                      border: "1px solid rgba(255,215,0,0.4)",
                      backdropFilter: "blur(4px)",
                    }}
                  >
                    <ZoomIn className="size-4 text-yellow-400" />
                  </div>
                  <span className="text-xs font-medium text-white/80 px-3 text-center leading-tight">
                    {photo.caption}
                  </span>
                </div>

                {/* Category badge */}
                <div className="absolute top-2 left-2">
                  <span
                    className="px-2 py-0.5 rounded-full text-[10px] font-medium opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{
                      background: "rgba(255,215,0,0.2)",
                      border: "1px solid rgba(255,215,0,0.3)",
                      color: "rgba(255,215,0,0.9)",
                    }}
                  >
                    {photo.category}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Add more photos notice */}
          <div
            className="mt-16 text-center p-6 rounded-2xl mx-auto max-w-lg"
            style={{
              background: "rgba(255,215,0,0.04)",
              border: "1px dashed rgba(255,215,0,0.2)",
            }}
          >
            <p className="text-yellow-400/60 text-sm mb-1 font-[Cinzel]">Add More Photos</p>
            <p className="text-white/30 text-xs">
              Place your images in <code className="text-yellow-400/50">public/gallery/</code> folder as{" "}
              <code className="text-yellow-400/50">photo-09.jpg</code>,{" "}
              <code className="text-yellow-400/50">photo-10.jpg</code> etc. and update the list in{" "}
              <code className="text-yellow-400/50">GalleryPage.tsx</code>
            </p>
          </div>
        </div>
      </section>

      {/* Lightbox */}
      {lightboxIndex !== null && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8"
          style={{ background: "rgba(0,0,0,0.96)", backdropFilter: "blur(12px)" }}
          onClick={closeLightbox}
        >
          {/* Close */}
          <button
            onClick={closeLightbox}
            className="absolute top-5 right-5 z-50 p-2 rounded-full border border-white/20 bg-white/5 hover:bg-white/10 hover:border-yellow-400/50 transition-colors text-white"
          >
            <X className="size-6" />
          </button>

          {/* Counter */}
          <div className="absolute top-5 left-1/2 -translate-x-1/2 z-50">
            <span className="text-white/40 text-xs font-[Cinzel] tracking-widest">
              {lightboxIndex + 1} / {filtered.length}
            </span>
          </div>

          {/* Prev */}
          <button
            onClick={prevPhoto}
            className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 z-50 p-3 rounded-full border border-white/20 bg-white/5 hover:bg-white/10 hover:border-yellow-400/50 transition-colors text-white hidden sm:block"
          >
            <ChevronLeft className="size-7" />
          </button>

          {/* Image */}
          <div
            className="relative flex items-center justify-center w-full max-w-5xl"
            onClick={(e) => e.stopPropagation()}
            style={{ animation: "scaleIn 0.25s ease-out" }}
          >
            <img
              src={filtered[lightboxIndex].src}
              alt={filtered[lightboxIndex].caption}
              className="max-w-full max-h-[82vh] object-contain rounded-xl"
              style={{
                boxShadow: "0 0 60px rgba(255,215,0,0.12)",
                border: "1px solid rgba(255,215,0,0.1)",
              }}
            />
            {/* Caption */}
            <div className="absolute bottom-0 inset-x-0 text-center pb-3 pt-10"
              style={{ background: "linear-gradient(transparent, rgba(0,0,0,0.7))", borderRadius: "0 0 0.75rem 0.75rem" }}
            >
              <p className="text-white/80 text-sm font-medium">{filtered[lightboxIndex].caption}</p>
              <p className="text-yellow-400/50 text-xs mt-0.5">{filtered[lightboxIndex].category}</p>
            </div>
          </div>

          {/* Next */}
          <button
            onClick={nextPhoto}
            className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 z-50 p-3 rounded-full border border-white/20 bg-white/5 hover:bg-white/10 hover:border-yellow-400/50 transition-colors text-white hidden sm:block"
          >
            <ChevronRight className="size-7" />
          </button>

          {/* Mobile bottom controls */}
          <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex items-center gap-4 sm:hidden z-50">
            <button onClick={prevPhoto} className="p-3 rounded-full bg-black/60 border border-white/20 text-white">
              <ChevronLeft className="size-5" />
            </button>
            <span className="text-white/50 text-xs font-[Cinzel]">{lightboxIndex + 1} / {filtered.length}</span>
            <button onClick={nextPhoto} className="p-3 rounded-full bg-black/60 border border-white/20 text-white">
              <ChevronRight className="size-5" />
            </button>
          </div>
        </div>
      )}

      <Footer />
      <WhatsAppFab />

      <style>{`
        @keyframes goldShimmer {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.94); }
          to   { opacity: 1; transform: scale(1); }
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(16px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </main>
  );
};

export default GalleryPage;
