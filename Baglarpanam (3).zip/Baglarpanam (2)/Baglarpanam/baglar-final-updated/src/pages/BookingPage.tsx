import { useEffect } from "react";
import { Link } from "react-router-dom";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Booking } from "@/components/site/Booking";
import { Footer } from "@/components/site/Footer";
import { WhatsAppFab } from "@/components/site/WhatsAppFab";
import { Flame, Home, ChevronRight } from "lucide-react";

const BookingPage = () => {
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  return (
    <main className="min-h-screen" style={{ background: "#050505" }}>
      <SiteHeader />

      {/* Page Hero Banner */}
      <section
        className="relative pt-24 md:pt-32 pb-16 overflow-hidden"
        style={{
          background: "linear-gradient(180deg,#0d0800 0%,#050505 100%)",
        }}
      >
        {/* Glow effects */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse 80% 60% at 50% 0%, rgba(255,215,0,0.06) 0%, transparent 70%)",
          }}
        />
        <div
          className="absolute left-0 top-0 w-[300px] h-[300px] pointer-events-none"
          style={{
            background:
              "radial-gradient(circle at 0% 0%, rgba(255,150,0,0.04) 0%, transparent 60%)",
          }}
        />
        <div
          className="absolute right-0 bottom-0 w-[300px] h-[300px] pointer-events-none"
          style={{
            background:
              "radial-gradient(circle at 100% 100%, rgba(255,215,0,0.04) 0%, transparent 60%)",
          }}
        />

        <div className="container relative z-10 text-center">
          {/* Breadcrumb */}
          <nav className="flex items-center justify-center gap-1.5 text-xs text-white/40 mb-8">
            <Link to="/" className="flex items-center gap-1 hover:text-yellow-400 transition-colors">
              <Home className="size-3" /> Home
            </Link>
            <ChevronRight className="size-3" />
            <span className="text-yellow-400">Booking</span>
          </nav>

          {/* Kicker */}
          <div className="flex items-center justify-center gap-3 mb-5">
            <span className="h-px w-14 bg-gradient-to-r from-transparent to-yellow-500/60" />
            <Flame className="size-4 text-yellow-400" />
            <span className="text-xs tracking-[0.45em] text-yellow-400 font-[Cinzel] uppercase">
              Sacred Puja Booking
            </span>
            <Flame className="size-4 text-yellow-400" />
            <span className="h-px w-14 bg-gradient-to-l from-transparent to-yellow-500/60" />
          </div>

          {/* Title */}
          <h1
            className="text-4xl md:text-6xl font-bold font-[Cinzel] mb-4"
            style={{ textShadow: "0 0 30px rgba(255,215,0,0.1)" }}
          >
            बुकिंग{" "}
            <span
              style={{
                background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
                backgroundSize: "200% 200%",
                animation: "goldShimmer 4s ease infinite",
              }}
            >
              करें
            </span>
          </h1>
          <p className="text-white/50 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Select your desired ritual, choose a convenient date, and complete your booking with secure payment. Divine blessings await you.
          </p>

          {/* Quick info pills */}
          <div className="flex flex-wrap items-center justify-center gap-3 mt-8">
            {[
              "✦ Online & Offline Puja",
              "✦ Secure Payment",
              "✦ WhatsApp Confirmation",
              "✦ Expert Pandits",
            ].map((text) => (
              <span
                key={text}
                className="px-4 py-1.5 rounded-full text-xs font-medium"
                style={{
                  background: "rgba(255,215,0,0.08)",
                  border: "1px solid rgba(255,215,0,0.2)",
                  color: "rgba(255,215,0,0.8)",
                }}
              >
                {text}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Booking section */}
      <Booking />

      <Footer />
      <WhatsAppFab />

      <style>{`
        @keyframes goldShimmer {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>
    </main>
  );
};

export default BookingPage;
