import { SiteHeader } from "@/components/site/SiteHeader";
import { Footer } from "@/components/site/Footer";
import { WhatsAppFab } from "@/components/site/WhatsAppFab";
import InquiryForm from "@/components/site/InquiryForm";

const Contact = () => {
  return (
    <main>
      <SiteHeader />
      <div className="min-h-[calc(100vh-80px)] pt-24 md:pt-32 pb-16">
        <div className="container">
          {/* Header Section */}
          <div className="mb-12 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gradient-gold">
              Get In Touch
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Have questions or ready to book our services? We'd love to hear from you.
              Fill out the form below and we'll get back to you as soon as possible.
            </p>
          </div>

          {/* Info Cards */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="p-6 rounded-lg border border-border/50 bg-background/50 backdrop-blur-sm hover:border-primary/50 transition-colors text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10 mb-4">
                <span className="text-xl">📧</span>
              </div>
              <h3 className="font-semibold mb-2">Email</h3>
              <p className="text-sm text-muted-foreground">contact@baglarpanam.com</p>
            </div>

            <div className="p-6 rounded-lg border border-border/50 bg-background/50 backdrop-blur-sm hover:border-primary/50 transition-colors text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10 mb-4">
                <span className="text-xl">📱</span>
              </div>
              <h3 className="font-semibold mb-2">Phone</h3>
              <p className="text-sm text-muted-foreground">+91 6265756977</p>
            </div>

            <div className="p-6 rounded-lg border border-border/50 bg-background/50 backdrop-blur-sm hover:border-primary/50 transition-colors text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10 mb-4">
                <span className="text-xl">📍</span>
              </div>
              <h3 className="font-semibold mb-2">Location</h3>
              <p className="text-sm text-muted-foreground">Baglar, Madhya Pradesh, India</p>
            </div>
          </div>

          {/* Form Section */}
          <div className="max-w-2xl mx-auto">
            <div className="p-8 rounded-lg border border-border/50 bg-background/50 backdrop-blur-sm">
              <InquiryForm />
            </div>
          </div>
        </div>
      </div>
      <Footer />
      <WhatsAppFab />
    </main>
  );
};

export default Contact;
