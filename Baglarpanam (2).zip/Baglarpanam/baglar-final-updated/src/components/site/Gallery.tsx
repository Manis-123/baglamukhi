import { useState, useEffect, useRef } from "react";
import hero from "@/assets/hero-baglamukhi.jpg";
import havan from "@/assets/havan.jpg";
import yantra from "@/assets/yantra.jpg";
import temple from "@/assets/temple.jpg";
import { useLang } from "@/i18n/LanguageProvider";
import { X, ChevronLeft, ChevronRight, ZoomIn } from "lucide-react";

/* ─── intersection observer hook ─── */
function useInView(threshold = 0.1) {
  const ref = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

export const Gallery = () => {
  const { t } = useLang();
  const { ref, inView } = useInView(0.1);
  const imgs = [hero, havan, temple, yantra, havan, temple];
  
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const openLightbox = (index: number) => {
    setCurrentIndex(index);
    setLightboxOpen(true);
    document.body.style.overflow = "hidden";
  };

  const closeLightbox = () => {
    setLightboxOpen(false);
    document.body.style.overflow = "";
  };

  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % imgs.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev - 1 + imgs.length) % imgs.length);
  };

  return (
    <section 
      id="gallery" 
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-28 overflow-hidden"
      style={{ background: "linear-gradient(180deg,#0a0700 0%,#050505 50%,#0a0700 100%)" }}
    >
      {/* ambient glows */}
      <div className="absolute right-0 top-1/4 w-[500px] h-[500px] pointer-events-none"
        style={{ background: "radial-gradient(ellipse at right, rgba(255,215,0,0.04) 0%, transparent 60%)" }} />
      <div className="absolute left-0 bottom-1/4 w-[400px] h-[400px] pointer-events-none"
        style={{ background: "radial-gradient(circle at left, rgba(255,150,0,0.03) 0%, transparent 60%)" }} />

      <div className="container relative z-10">
        
        {/* Section label */}
        <div
          className={`flex items-center justify-center gap-3 mb-6 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
        >
          <span className="h-px w-16 bg-gradient-to-r from-transparent to-yellow-500/60" />
          <p className="text-xs tracking-[0.45em] text-yellow-400 font-[Cinzel] uppercase">
            {t("gallery.kicker")}
          </p>
          <span className="h-px w-16 bg-gradient-to-l from-transparent to-yellow-500/60" />
        </div>

        {/* Heading */}
        <div
          className={`text-center mb-14 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
          style={{ transitionDelay: "100ms" }}
        >
          <h2
            className="text-3xl md:text-5xl font-bold font-[Cinzel]"
            style={{ textShadow: "0 0 20px rgba(255,215,0,0.12)" }}
          >
            {t("gallery.title.1")}{" "}
            <span style={{
              background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
              backgroundSize: "200% 200%", animation: "goldShimmer 4s ease infinite",
            }}>
              {t("gallery.title.gold")}
            </span>
          </h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-5 md:gap-7">
          {imgs.map((src, idx) => (
            <div 
              key={idx} 
              onClick={() => openLightbox(idx)}
              className={`group relative aspect-[4/5] md:aspect-square rounded-2xl overflow-hidden cursor-pointer transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
              style={{
                transitionDelay: `${200 + (idx * 100)}ms`,
                background: "rgba(20,16,8,0.9)",
                border: "1px solid rgba(255,215,0,0.15)",
                boxShadow: "0 4px 20px rgba(0,0,0,0.4)"
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLElement).style.boxShadow = "0 8px 30px rgba(255,215,0,0.15)";
                (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,215,0,0.4)";
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 20px rgba(0,0,0,0.4)";
                (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,215,0,0.15)";
              }}
            >
              <img 
                src={src} 
                alt="" 
                loading="lazy" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
              />
              
              {/* Overlay on hover */}
              <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div 
                  className="w-12 h-12 rounded-full grid place-items-center scale-75 group-hover:scale-100 transition-transform duration-500"
                  style={{
                    background: "rgba(255,215,0,0.15)",
                    border: "1px solid rgba(255,215,0,0.4)",
                    backdropFilter: "blur(4px)"
                  }}
                >
                  <ZoomIn className="size-5 text-yellow-400" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Overlay */}
      {lightboxOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8"
          style={{ background: "rgba(0,0,0,0.95)", backdropFilter: "blur(8px)" }}
          onClick={closeLightbox}
        >
          {/* Close button */}
          <button 
            onClick={closeLightbox}
            className="absolute top-6 right-6 md:top-8 md:right-8 z-50 p-2 rounded-full border border-white/20 bg-white/5 hover:bg-white/10 hover:border-yellow-400/50 transition-colors text-white"
          >
            <X className="size-6" />
          </button>

          {/* Prev button */}
          <button 
            onClick={prevImage}
            className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 z-50 p-3 rounded-full border border-white/20 bg-white/5 hover:bg-white/10 hover:border-yellow-400/50 transition-colors text-white hidden sm:block"
          >
            <ChevronLeft className="size-8" />
          </button>

          {/* Image */}
          <div 
            className="relative w-full max-w-5xl aspect-auto max-h-full flex items-center justify-center"
            onClick={(e) => e.stopPropagation()}
            style={{ animation: "scaleIn 0.3s ease-out" }}
          >
            <img 
              src={imgs[currentIndex]} 
              alt="Gallery Preview" 
              className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-[0_0_50px_rgba(255,215,0,0.15)] border border-yellow-500/10" 
            />
          </div>

          {/* Next button */}
          <button 
            onClick={nextImage}
            className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 z-50 p-3 rounded-full border border-white/20 bg-white/5 hover:bg-white/10 hover:border-yellow-400/50 transition-colors text-white hidden sm:block"
          >
            <ChevronRight className="size-8" />
          </button>

          {/* Mobile nav controls at bottom */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-4 sm:hidden z-50">
            <button onClick={prevImage} className="p-3 rounded-full bg-black/50 border border-white/20 text-white"><ChevronLeft className="size-6" /></button>
            <span className="text-white/60 font-[Cinzel] tracking-widest">{currentIndex + 1} / {imgs.length}</span>
            <button onClick={nextImage} className="p-3 rounded-full bg-black/50 border border-white/20 text-white"><ChevronRight className="size-6" /></button>
          </div>
        </div>
      )}

      <style>{`
        @keyframes goldShimmer {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.95); }
          to   { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </section>
  );
};
