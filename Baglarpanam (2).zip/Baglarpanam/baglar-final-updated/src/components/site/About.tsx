import { Check, Flame, Star, Shield } from "lucide-react";
import temple from "@/assets/temple.jpg";
import yantra from "@/assets/yantra.jpg";
import { useLang } from "@/i18n/LanguageProvider";
import { useEffect, useRef, useState } from "react";

/* ─── intersection observer hook ─── */
function useInView(threshold = 0.2) {
  const ref = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const ICON_MAP = [Flame, Star, Shield, Check];

export const About = () => {
  const { t } = useLang();
  const points = [
    t("about.point1"),
    t("about.point2"),
    t("about.point3"),
    t("about.point4"),
  ];

  const { ref, inView } = useInView(0.15);

  /* image hover tilt */
  const imgWrapRef = useRef<HTMLDivElement>(null);
  const handleTilt = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = imgWrapRef.current;
    if (!el) return;
    const { left, top, width, height } = el.getBoundingClientRect();
    const x = ((e.clientX - left) / width - 0.5) * 10;
    const y = ((e.clientY - top) / height - 0.5) * -10;
    el.style.transform = `perspective(800px) rotateY(${x}deg) rotateX(${y}deg) scale(1.02)`;
  };
  const resetTilt = () => {
    if (imgWrapRef.current)
      imgWrapRef.current.style.transform =
        "perspective(800px) rotateY(0deg) rotateX(0deg) scale(1)";
  };

  return (
    <section
      id="about"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-28 overflow-hidden"
      style={{ background: "linear-gradient(180deg,#050505 0%,#0d0a00 50%,#050505 100%)" }}
    >
      {/* ambient glow blobs */}
      <div className="absolute -left-40 top-20 w-80 h-80 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(255,215,0,0.07) 0%, transparent 70%)" }} />
      <div className="absolute -right-40 bottom-20 w-96 h-96 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(255,150,0,0.05) 0%, transparent 70%)" }} />

      <div className="container relative z-10">

        {/* ── section label ── */}
        <div
          className={`flex items-center justify-center gap-3 mb-16 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
          style={{ transitionDelay: "0ms" }}
        >
          <span className="h-px w-16 bg-gradient-to-r from-transparent to-yellow-500/60" />
          <p className="text-xs tracking-[0.45em] text-yellow-400 font-[Cinzel] uppercase">
            {t("about.kicker")}
          </p>
          <span className="h-px w-16 bg-gradient-to-l from-transparent to-yellow-500/60" />
        </div>

        <div className="grid md:grid-cols-2 gap-16 items-center">

          {/* ── IMAGE side ── */}
          <div
            className={`transition-all duration-800 ${inView ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"}`}
            style={{ transitionDelay: "100ms" }}
          >
            <div
              ref={imgWrapRef}
              onMouseMove={handleTilt}
              onMouseLeave={resetTilt}
              className="relative rounded-2xl overflow-hidden cursor-pointer"
              style={{
                transition: "transform 0.18s ease-out",
                transformStyle: "preserve-3d",
                boxShadow: "0 0 60px rgba(255,215,0,0.08), 0 24px 60px rgba(0,0,0,0.6)",
                border: "1px solid rgba(255,215,0,0.18)",
              }}
            >
              {/* main temple image */}
              <img
                src={temple}
                alt="Baglamukhi Temple — Nalkheda Siddh Peeth"
                loading="lazy"
                className="w-full h-80 md:h-[420px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

              {/* floating yantra badge */}
              <div
                className="absolute bottom-4 right-4 w-20 h-20 rounded-full overflow-hidden border-2"
                style={{
                  borderColor: "rgba(255,215,0,0.5)",
                  boxShadow: "0 0 20px rgba(255,215,0,0.3)",
                  animation: "slowSpin 24s linear infinite",
                }}
              >
                <img src={yantra} alt="Baglamukhi Yantra" className="w-full h-full object-cover" />
              </div>

              {/* experience badge */}
              <div
                className="absolute top-4 left-4 px-3 py-2 rounded-xl backdrop-blur-md text-left"
                style={{
                  background: "rgba(0,0,0,0.55)",
                  border: "1px solid rgba(255,215,0,0.3)",
                }}
              >
                <div className="text-xl font-bold text-yellow-400 font-[Cinzel]">15+</div>
                <div className="text-[10px] uppercase tracking-widest text-white/70">Years of Siddhi</div>
              </div>

              {/* bottom caption */}
              <div className="absolute bottom-0 left-0 right-0 px-5 py-4">
                <p className="text-white font-semibold text-sm font-[Cinzel]">
                  Baglamukhi Siddh Peeth, Nalkheda
                </p>
                <p className="text-white/60 text-xs mt-0.5">Madhya Pradesh, India</p>
              </div>
            </div>
          </div>

          {/* ── TEXT side ── */}
          <div
            className={`transition-all duration-800 ${inView ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"}`}
            style={{ transitionDelay: "200ms" }}
          >
            <h2
              className="text-3xl md:text-4xl font-bold leading-tight font-[Cinzel]"
              style={{ textShadow: "0 0 20px rgba(255,215,0,0.15)" }}
            >
              {t("about.title.1")}{" "}
              <span
                style={{
                  background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                  backgroundSize: "200% 200%",
                  animation: "goldShimmer 4s ease infinite",
                }}
              >
                {t("about.title.gold")}
              </span>{" "}
              {t("about.title.2")}
            </h2>

            <p className="mt-5 text-white/65 leading-relaxed text-[15px]">
              {t("about.body")}
            </p>

            {/* divider */}
            <div className="my-7 h-px w-full bg-gradient-to-r from-yellow-500/30 via-yellow-400/10 to-transparent" />

            {/* ── feature points ── */}
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {points.map((p, i) => {
                const Icon = ICON_MAP[i % ICON_MAP.length];
                return (
                  <li
                    key={p}
                    className={`group flex items-start gap-3 p-3 rounded-xl border border-transparent hover:border-yellow-500/20 hover:bg-yellow-400/[0.04] transition-all duration-300 cursor-default transition-all duration-600 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
                    style={{ transitionDelay: `${350 + i * 80}ms` }}
                  >
                    <span
                      className="mt-0.5 grid place-items-center size-7 rounded-full shrink-0 transition-all duration-300 group-hover:scale-110"
                      style={{
                        background: "rgba(255,215,0,0.12)",
                        border: "1px solid rgba(255,215,0,0.3)",
                        boxShadow: "0 0 10px rgba(255,215,0,0)",
                      }}
                      onMouseEnter={(e) => {
                        (e.currentTarget as HTMLElement).style.boxShadow =
                          "0 0 14px rgba(255,215,0,0.35)";
                      }}
                      onMouseLeave={(e) => {
                        (e.currentTarget as HTMLElement).style.boxShadow =
                          "0 0 10px rgba(255,215,0,0)";
                      }}
                    >
                      <Icon className="size-3.5 text-yellow-400" />
                    </span>
                    <span className="text-sm text-white/80 group-hover:text-white transition-colors duration-300 leading-relaxed">
                      {p}
                    </span>
                  </li>
                );
              })}
            </ul>

            {/* trust mini-strip */}
            <div className="mt-8 flex flex-wrap gap-5">
              {[
                { num: "5000+", label: "Rituals Completed" },
                { num: "21", label: "States Served" },
                { num: "100%", label: "Shastriya Vidhi" },
              ].map((item) => (
                <div key={item.label} className="text-center">
                  <div className="text-xl font-bold text-yellow-400 font-[Cinzel]">{item.num}</div>
                  <div className="text-[10px] uppercase tracking-widest text-white/50 mt-0.5">
                    {item.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* keyframes */}
      <style>{`
        @keyframes slowSpin {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
        @keyframes goldShimmer {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>
    </section>
  );
};
