import { Quote } from "lucide-react";
import { useLang } from "@/i18n/LanguageProvider";

export const Testimonials = () => {
  const { t } = useLang();
  const items = [
    { text: t("test.t1.text"), name: t("test.t1.name"), place: t("test.t1.place") },
    { text: t("test.t2.text"), name: t("test.t2.name"), place: t("test.t2.place") },
    { text: t("test.t3.text"), name: t("test.t3.name"), place: t("test.t3.place") },
  ];
  return (
    <section className="py-24 container">
      <div className="text-center mb-14">
        <p className="text-xs tracking-[0.35em] text-primary mb-3">{t("test.kicker")}</p>
        <h2 className="text-3xl md:text-5xl font-bold">
          {t("test.title.1")} <span className="text-gradient-gold">{t("test.title.gold")}</span>
        </h2>
      </div>
      <div className="grid md:grid-cols-3 gap-6">
        {items.map((it) => (
          <figure key={it.name} className="relative rounded-2xl p-8 border border-primary/20 shadow-card" style={{ background: "var(--gradient-card)" }}>
            <Quote className="size-8 text-primary/60 mb-4" />
            <blockquote className="text-foreground/90 leading-relaxed">"{it.text}"</blockquote>
            <figcaption className="mt-6 pt-4 border-t border-border">
              <div className="font-semibold">{it.name}</div>
              <div className="text-xs text-muted-foreground">{it.place} · {t("test.verified")}</div>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
};
