import { useState } from "react";
import { Button } from "@/components/ui/button";
import { MessageCircle } from "lucide-react";
import { useLang } from "@/i18n/LanguageProvider";
import { LanguageSwitcher } from "./LanguageSwitcher";

export const Navbar = () => {
  const { t } = useLang();
  const [isAboutOpen, setIsAboutOpen] = useState(false);

  const otherLinks = [
    { label: t("nav.services"), href: "#services" },
    { label: t("nav.booking"), href: "#booking" },
    { label: t("nav.donation"), href: "#donation" },
    { label: t("nav.gallery"), href: "#gallery" },
    { label: t("nav.contact"), href: "/contact" },
  ];

  const leftMenuItems = [
    { label: "Temple", href: "#temple" },
    { label: "History", href: "#history" },
  ];

  const rightMenuItems = [
    { label: "About Temple", href: "#about-temple" },
    { label: "Temple Timings", href: "#temple-timings" },
  ];

  return (
    <header className="fixed top-0 inset-x-0 z-50 backdrop-blur-md bg-background/70 border-b border-border/60">
      <nav className="container flex items-center justify-between h-16 md:h-20 gap-3">
        <a href="#" className="flex flex-col leading-tight">
          <span className="font-[Cinzel] text-xl md:text-2xl text-gradient-gold font-bold">
            {t("brand.name")}
          </span>
          <span className="text-[10px] md:text-xs text-muted-foreground tracking-widest">
            {t("brand.tagline")}
          </span>
        </a>

        <div className="hidden lg:flex items-center gap-8">
          {/* About Dropdown Menu */}
          <div
            className="relative group"
            onMouseEnter={() => setIsAboutOpen(true)}
            onMouseLeave={() => setIsAboutOpen(false)}
          >
            <button className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors flex items-center gap-1">
              {t("nav.about")}
              <svg
                className={`w-4 h-4 transition-transform duration-200 ${isAboutOpen ? "rotate-180" : ""
                  }`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 14l-7 7m0 0l-7-7m7 7V3"
                />
              </svg>
            </button>

            {/* Dropdown Content */}
            <div
              className={`absolute left-0 mt-0 pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-40`}
            >
              <div className="bg-black rounded-lg shadow-lg border border-gray-700 p-6 w-80">
                {/* Two Column Layout */}
                <div className="flex gap-8">
                  {/* Left Column */}
                  <div className="flex-1">
                    {leftMenuItems.map((item) => (
                      <a
                        key={item.href}
                        href={item.href}
                        className="block py-2.5 px-3 rounded-md text-sm font-medium text-white hover:bg-gray-900 hover:text-primary transition-all duration-150"
                      >
                        {item.label}
                      </a>
                    ))}
                  </div>

                  {/* Right Column */}
                  <div className="flex-1">
                    {rightMenuItems.map((item) => (
                      <a
                        key={item.href}
                        href={item.href}
                        className="block py-2.5 px-3 rounded-md text-sm font-medium text-white hover:bg-gray-900 hover:text-primary transition-all duration-150"
                      >
                        {item.label}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Other Links */}
          {otherLinks.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors"
            >
              {l.label}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <LanguageSwitcher />
          <Button variant="hero" size="sm" asChild>
            <a href="https://wa.me/919424072531" target="_blank" rel="noreferrer">
              <MessageCircle className="size-4" />
              <span className="hidden sm:inline">{t("nav.whatsapp")}</span>
            </a>
          </Button>
        </div>
      </nav>
    </header>
  );
};
