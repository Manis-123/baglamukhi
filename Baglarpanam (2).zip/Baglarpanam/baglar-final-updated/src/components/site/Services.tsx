import { Flame, Scale, TrendingUp, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLang } from "@/i18n/LanguageProvider";

export const Services = () => {
  const { t } = useLang();
  const services = [
    { icon: Flame, title: t("services.s1.title"), desc: t("services.s1.desc") },
    { icon: Scale, title: t("services.s2.title"), desc: t("services.s2.desc") },
    { icon: TrendingUp, title: t("services.s3.title"), desc: t("services.s3.desc") },
    { icon: Shield, title: t("services.s4.title"), desc: t("services.s4.desc") },
  ];
  return (
    <section id="services" className="py-24 relative">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <p className="text-xs tracking-[0.35em] text-primary mb-3">{t("services.kicker")}</p>
          <h2 className="text-3xl md:text-5xl font-bold">
            {t("services.title.1")} <span className="text-gradient-gold">{t("services.title.gold")}</span>
          </h2>
          <div className="h-px w-32 mx-auto mt-6 divider-gold" />
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((s) => (
            <article key={s.title} className="group relative rounded-2xl p-6 border border-border hover:border-primary/60 transition-all duration-300 hover:-translate-y-1 shadow-card overflow-hidden" style={{ background: "var(--gradient-card)" }}>
              <div className="absolute -top-12 -right-12 size-40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" style={{ background: "var(--gradient-radial-gold)" }} />
              <div className="relative">
                <div className="size-14 rounded-xl bg-primary/15 text-primary grid place-items-center mb-5 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  <s.icon className="size-7" />
                </div>
                <h3 className="text-xl font-bold mb-2">{s.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
                <Button variant="ghostGold" size="sm" className="mt-5 px-0" asChild>
                  <a href="#booking">{t("services.cta")}</a>
                </Button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};
