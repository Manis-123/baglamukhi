import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Mail, Phone, User, MessageSquare, ChevronRight, CheckCircle2 } from "lucide-react";
import { useLang } from "@/i18n/LanguageProvider";
import { sendInquiryToWhatsApp } from "@/lib/whatsapp";

interface InquiryFormProps {
  onSubmitSuccess?: () => void;
}

const InquiryForm = ({ onSubmitSuccess }: InquiryFormProps) => {
  const { t } = useLang();
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });

  const services = [
    "General Inquiry",
    "Booking & Anushthan",
    "Pricing Information",
    "Live Sankalp Details",
    "Other",
  ];

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleServiceChange = (value: string) => {
    setFormData((prev) => ({ ...prev, service: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.email || !formData.phone || !formData.service || !formData.message) {
      toast.error("Please fill in all fields.");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      toast.error("Please enter a valid email address.");
      return;
    }

    if (formData.phone.length < 10) {
      toast.error("Please enter a valid phone number.");
      return;
    }

    setLoading(true);

    try {
      sendInquiryToWhatsApp(formData);

      setSubmitted(true);
      toast.success("Inquiry submitted successfully!");

      setFormData({ name: "", email: "", phone: "", service: "", message: "" });

      if (onSubmitSuccess) {
        setTimeout(() => onSubmitSuccess(), 1500);
      }

      setTimeout(() => setSubmitted(false), 4000);
    } catch (error) {
      console.error("Error submitting:", error);
      toast.error("Failed to submit inquiry. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  /* input styling consistent with premium UI */
  const inputCls = "w-full pl-10 px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-sm text-white placeholder:text-white/30 outline-none transition-all duration-300 focus:bg-white/[0.06] focus:border-yellow-500/50 focus:ring-1 focus:ring-yellow-500/30";
  const labelCls = "text-xs font-semibold text-white/50 uppercase tracking-wider group-focus-within:text-yellow-400 transition-colors";
  const iconCls = "absolute left-3 top-1/2 -translate-y-1/2 size-4 text-white/20 group-focus-within:text-yellow-400/60 transition-colors pointer-events-none";

  if (submitted) {
    return (
      <div 
        className="flex flex-col items-center justify-center py-16 px-6 text-center rounded-2xl border border-yellow-500/20"
        style={{
          background: "linear-gradient(145deg, rgba(20,16,8,0.95) 0%, rgba(10,8,4,0.98) 100%)",
          boxShadow: "0 0 50px rgba(255,215,0,0.05)",
          animation: "scaleIn 0.4s cubic-bezier(0.16, 1, 0.3, 1)"
        }}
      >
        <div className="relative mb-6">
          <div className="absolute inset-0 rounded-full bg-yellow-500/20 blur-xl scale-150" />
          <CheckCircle2 className="size-16 text-yellow-400 relative z-10" strokeWidth={1.5} />
        </div>
        <h3 className="text-2xl font-bold font-[Cinzel] text-white mb-2" style={{ textShadow: "0 0 15px rgba(255,215,0,0.2)" }}>
          Inquiry Sent Successfully! 🙏
        </h3>
        <p className="text-white/60 mb-6 max-w-sm leading-relaxed text-sm">
          Thank you for reaching out. A temple representative will get back to you shortly via WhatsApp.
        </p>
        <div className="text-xs text-yellow-400/60 font-[Cinzel] italic tracking-wide">
          "Om Hreem Baglamukhi Sarva Dushtanaam"
        </div>
      </div>
    );
  }

  return (
    <form 
      onSubmit={handleSubmit} 
      className="w-full space-y-6 rounded-2xl p-6 sm:p-8 relative overflow-hidden"
      style={{
        background: "linear-gradient(145deg, rgba(20,16,8,0.95) 0%, rgba(10,8,4,0.98) 100%)",
        border: "1px solid rgba(255,215,0,0.15)",
        boxShadow: "0 0 40px rgba(255,215,0,0.04)"
      }}
    >
      {/* ambient top glow */}
      <div className="absolute top-0 right-0 w-32 h-32 pointer-events-none" style={{ background: "radial-gradient(circle at top right, rgba(255,215,0,0.06) 0%, transparent 70%)" }} />

      <div className="text-center mb-6">
        <h3 className="text-xl font-bold font-[Cinzel] text-yellow-400">Send an Inquiry</h3>
        <p className="text-xs text-white/40 mt-1">We will respond as soon as possible.</p>
      </div>

      <div className="grid sm:grid-cols-2 gap-5">
        {/* Name Field */}
        <div className="space-y-1.5 group">
          <Label htmlFor="name" className={labelCls}>Name <span className="text-yellow-400">*</span></Label>
          <div className="relative mt-1">
            <User className={iconCls} />
            <Input id="name" name="name" placeholder="Your full name" value={formData.name} onChange={handleChange} disabled={loading} className={inputCls} />
          </div>
        </div>

        {/* Phone Field */}
        <div className="space-y-1.5 group">
          <Label htmlFor="phone" className={labelCls}>Phone <span className="text-yellow-400">*</span></Label>
          <div className="relative mt-1">
            <Phone className={iconCls} />
            <Input id="phone" name="phone" placeholder="+91 ..." value={formData.phone} onChange={handleChange} disabled={loading} className={inputCls} type="tel" />
          </div>
        </div>
      </div>

      {/* Email Field */}
      <div className="space-y-1.5 group">
        <Label htmlFor="email" className={labelCls}>Email <span className="text-yellow-400">*</span></Label>
        <div className="relative mt-1">
          <Mail className={iconCls} />
          <Input id="email" name="email" type="email" placeholder="your.email@example.com" value={formData.email} onChange={handleChange} disabled={loading} className={inputCls} />
        </div>
      </div>

      {/* Service Selection */}
      <div className="space-y-1.5 group">
        <Label htmlFor="service" className={labelCls}>Subject <span className="text-yellow-400">*</span></Label>
        <Select value={formData.service} onValueChange={handleServiceChange} disabled={loading}>
          <SelectTrigger className="w-full bg-white/[0.04] border-white/10 text-white focus:ring-1 focus:ring-yellow-500/40 focus:border-yellow-500/50 outline-none transition-all duration-300">
            <SelectValue placeholder="Select a subject topic" />
          </SelectTrigger>
          <SelectContent className="bg-[#0a0700] border-yellow-500/20 text-white">
            {services.map((service) => (
              <SelectItem key={service} value={service} className="hover:bg-white/5 focus:bg-white/10 focus:text-yellow-400 cursor-pointer transition-colors">
                {service}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Message Field */}
      <div className="space-y-1.5 group">
        <Label htmlFor="message" className={labelCls}>Message <span className="text-yellow-400">*</span></Label>
        <div className="relative mt-1">
          <MessageSquare className={`absolute left-3 top-3 size-4 text-white/20 group-focus-within:text-yellow-400/60 transition-colors pointer-events-none`} />
          <Textarea id="message" name="message" placeholder="Please describe your inquiry in detail..." value={formData.message} onChange={handleChange} disabled={loading} rows={4} className={`${inputCls} pl-10 resize-none`} style={{ paddingLeft: "2.5rem" }} />
        </div>
      </div>

      {/* Submit Button */}
      <button 
        type="submit" 
        disabled={loading}
        className="group w-full py-3.5 mt-2 rounded-xl font-bold flex items-center justify-center gap-2 relative overflow-hidden transition-all duration-300 hover:scale-[1.01] disabled:opacity-70 disabled:cursor-not-allowed disabled:hover:scale-100"
        style={{
          background: "linear-gradient(135deg,#FFD700,#FDB931)",
          color: "#000",
          boxShadow: loading ? "none" : "0 0 25px rgba(255,215,0,0.25)"
        }}
      >
        <span className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
        <span className="relative z-10 flex items-center gap-2">
          {loading ? "Processing..." : "Send Inquiry via WhatsApp"}
          {!loading && <ChevronRight className="size-4 group-hover:translate-x-1 transition-transform" />}
        </span>
      </button>

      <style>{`
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.96); }
          to   { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </form>
  );
};

export default InquiryForm;
