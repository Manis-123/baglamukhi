import { useState, useEffect, useRef } from "react";
import { useLang } from "@/i18n/LanguageProvider";
import { Plus, Minus, HelpCircle } from "lucide-react";

/* ─── intersection observer hook ─── */
function useInView(threshold = 0.12) {
  const ref = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

/* ─── single FAQ item ─── */
interface FaqItemProps {
  question: string;
  answer: string;
  index: number;
  isOpen: boolean;
  onToggle: () => void;
  visible: boolean;
}

const FaqItem = ({ question, answer, index, isOpen, onToggle, visible }: FaqItemProps) => {
  const contentRef = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState(0);

  useEffect(() => {
    if (contentRef.current) {
      setHeight(isOpen ? contentRef.current.scrollHeight : 0);
    }
  }, [isOpen]);

  return (
    <div
      className={`group rounded-2xl overflow-hidden transition-all duration-700 cursor-pointer ${
        visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      }`}
      style={{
        transitionDelay: `${index * 100}ms`,
        background: isOpen
          ? "linear-gradient(145deg, rgba(25,20,10,0.98) 0%, rgba(15,12,5,0.99) 100%)"
          : "linear-gradient(145deg, rgba(20,16,8,0.90) 0%, rgba(10,8,4,0.95) 100%)",
        border: isOpen
          ? "1px solid rgba(255,215,0,0.35)"
          : "1px solid rgba(255,215,0,0.12)",
        boxShadow: isOpen
          ? "0 0 30px rgba(255,215,0,0.08), 0 8px 32px rgba(0,0,0,0.4)"
          : "0 4px 16px rgba(0,0,0,0.3)",
        transition: "border-color 0.4s ease, box-shadow 0.4s ease, background 0.4s ease, opacity 0.7s ease, transform 0.7s ease",
      }}
      onClick={onToggle}
    >
      {/* Question row */}
      <div className="flex items-center gap-4 px-6 py-5">
        {/* number badge */}
        <div
          className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold font-[Cinzel] transition-all duration-400"
          style={{
            background: isOpen
              ? "linear-gradient(135deg, #FFD700, #FDB931)"
              : "rgba(255,215,0,0.08)",
            border: isOpen ? "none" : "1px solid rgba(255,215,0,0.2)",
            color: isOpen ? "#000" : "rgba(255,215,0,0.6)",
            boxShadow: isOpen ? "0 0 12px rgba(255,215,0,0.3)" : "none",
          }}
        >
          {String(index + 1).padStart(2, "0")}
        </div>

        <span
          className="flex-1 font-[Cinzel] text-sm md:text-base font-semibold leading-snug transition-colors duration-300"
          style={{ color: isOpen ? "#FFD700" : "rgba(255,255,255,0.85)" }}
        >
          {question}
        </span>

        <div
          className="shrink-0 grid place-items-center size-7 rounded-full transition-all duration-400"
          style={{
            background: isOpen ? "rgba(255,215,0,0.12)" : "rgba(255,255,255,0.04)",
            border: isOpen ? "1px solid rgba(255,215,0,0.3)" : "1px solid rgba(255,255,255,0.08)",
          }}
        >
          {isOpen
            ? <Minus className="size-3.5 text-yellow-400 transition-transform duration-300" />
            : <Plus className="size-3.5 text-white/40 transition-transform duration-300 group-hover:text-yellow-400/70" />
          }
        </div>
      </div>

      {/* Answer — animated height */}
      <div
        style={{
          height,
          overflow: "hidden",
          transition: "height 0.4s cubic-bezier(0.4, 0, 0.2, 1)",
        }}
      >
        <div ref={contentRef}>
          {/* gold top divider */}
          <div
            className="mx-6 mb-4"
            style={{
              height: "1px",
              background: "linear-gradient(90deg, transparent, rgba(255,215,0,0.25), transparent)",
            }}
          />
          <p className="px-6 pb-6 text-sm text-white/65 leading-relaxed" style={{ fontFamily: "Inter, sans-serif" }}>
            {answer}
          </p>
        </div>
      </div>
    </div>
  );
};

/* ─── main FAQ section ─── */
export const FAQ = () => {
  const { t } = useLang();
  const { ref, inView } = useInView(0.1);
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    { q: t("faq.q1"), a: t("faq.a1") },
    { q: t("faq.q2"), a: t("faq.a2") },
    { q: t("faq.q3"), a: t("faq.a3") },
    { q: t("faq.q4"), a: t("faq.a4") },
  ];

  const toggle = (i: number) => setOpenIndex(prev => (prev === i ? null : i));

  return (
    <section
      id="faq"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-28 overflow-hidden"
      style={{ background: "linear-gradient(180deg,#050505 0%,#0a0700 50%,#050505 100%)" }}
    >
      {/* ambient glows */}
      <div className="absolute left-1/2 -translate-x-1/2 top-0 w-[600px] h-[300px] pointer-events-none"
        style={{ background: "radial-gradient(ellipse at center, rgba(255,215,0,0.04) 0%, transparent 70%)" }} />
      <div className="absolute -left-32 bottom-20 w-72 h-72 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(255,150,0,0.03) 0%, transparent 70%)" }} />

      <div className="container relative z-10 max-w-3xl">

        {/* Section label */}
        <div
          className={`flex items-center justify-center gap-3 mb-6 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
        >
          <span className="h-px w-16 bg-gradient-to-r from-transparent to-yellow-500/60" />
          <p className="text-xs tracking-[0.45em] text-yellow-400 font-[Cinzel] uppercase">
            {t("faq.kicker")}
          </p>
          <span className="h-px w-16 bg-gradient-to-l from-transparent to-yellow-500/60" />
        </div>

        {/* Heading */}
        <div
          className={`text-center mb-14 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
          style={{ transitionDelay: "100ms" }}
        >
          <HelpCircle className="size-10 text-yellow-400/30 mx-auto mb-4"
            style={{ filter: "drop-shadow(0 0 12px rgba(255,215,0,0.25))" }} />
          <h2
            className="text-3xl md:text-5xl font-bold font-[Cinzel]"
            style={{ textShadow: "0 0 20px rgba(255,215,0,0.12)" }}
          >
            {t("faq.title.1")}{" "}
            <span style={{
              background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
              backgroundSize: "200% 200%", animation: "goldShimmer 4s ease infinite",
            }}>
              {t("faq.title.gold")}
            </span>
          </h2>
        </div>

        {/* FAQ items */}
        <div className="space-y-3">
          {faqs.map((f, i) => (
            <FaqItem
              key={i}
              index={i}
              question={f.q}
              answer={f.a}
              isOpen={openIndex === i}
              onToggle={() => toggle(i)}
              visible={inView}
            />
          ))}
        </div>

        {/* Bottom CTA */}
        <div
          className={`mt-12 text-center transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
          style={{ transitionDelay: "500ms" }}
        >
          <p className="text-white/40 text-sm mb-4">Still have a question? We're here to help.</p>
          <a
            href="https://wa.me/919424072531?text=Jai%20Maa%20Baglamukhi!%20I%20have%20a%20question%20about%20your%20services."
            target="_blank"
            rel="noreferrer"
            className="group inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold transition-all duration-300 hover:scale-105"
            style={{
              background: "rgba(255,215,0,0.08)",
              border: "1px solid rgba(255,215,0,0.2)",
              color: "rgba(255,215,0,0.8)",
              boxShadow: "0 0 0 rgba(255,215,0,0)",
            }}
            onMouseEnter={e => {
              (e.currentTarget as HTMLElement).style.boxShadow = "0 0 20px rgba(255,215,0,0.15)";
              (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,215,0,0.4)";
              (e.currentTarget as HTMLElement).style.color = "#FFD700";
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLElement).style.boxShadow = "0 0 0 rgba(255,215,0,0)";
              (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,215,0,0.2)";
              (e.currentTarget as HTMLElement).style.color = "rgba(255,215,0,0.8)";
            }}
          >
            💬 Ask on WhatsApp
            <span className="group-hover:translate-x-1 transition-transform duration-300">→</span>
          </a>
        </div>
      </div>

      <style>{`
        @keyframes goldShimmer {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>
    </section>
  );
};
