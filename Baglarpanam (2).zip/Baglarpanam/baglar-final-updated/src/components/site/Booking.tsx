import { useState, useEffect, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Shield, Lock, CreditCard, Smartphone, Building2, CheckCircle2, X, ChevronRight, Loader2, Calendar, User, Phone, Flame } from "lucide-react";
import havan from "@/assets/havan.jpg";
import { useLang } from "@/i18n/LanguageProvider";
import { sendBookingToWhatsApp } from "@/lib/whatsapp";

/* ─── intersection observer hook ─── */
function useInView(threshold = 0.15) {
  const ref = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const RITUAL_PRICES: Record<number, number> = {
  0: 5100, 1: 7500, 2: 4100, 3: 3500, 4: 9100, 5: 2100,
};

const UpiIcon = () => (
  <svg viewBox="0 0 80 28" width="52" height="22" xmlns="http://www.w3.org/2000/svg">
    <text x="2" y="20" fontSize="16" fontWeight="900" fill="#6B3FA0" fontFamily="Arial">UPI</text>
    <line x1="38" y1="4" x2="38" y2="24" stroke="#6B3FA0" strokeWidth="2" />
    <text x="44" y="20" fontSize="11" fontWeight="600" fill="#888" fontFamily="Arial">Pay</text>
  </svg>
);

const RazorpayIcon = () => (
  <svg viewBox="0 0 80 20" width="72" height="18" xmlns="http://www.w3.org/2000/svg">
    <text x="0" y="15" fontSize="13" fontWeight="700" fill="#072654" fontFamily="Arial">Razorpay</text>
  </svg>
);

const NetbankingBadge = () => (
  <div className="flex items-center gap-1 px-2 py-1 rounded border border-primary/30 bg-white/5">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#c8a84b" strokeWidth="2">
      <rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </svg>
    <span className="text-[10px] text-muted-foreground font-medium">Netbanking</span>
  </div>
);

type PayTab = "upi" | "card" | "netbanking";

const BANKS = [
  "State Bank of India", "HDFC Bank", "ICICI Bank", "Axis Bank",
  "Punjab National Bank", "Bank of Baroda", "Kotak Mahindra Bank", "Yes Bank",
];

interface PaymentModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
  amount: number;
  ritualName: string;
  customerName: string;
}

const PaymentModal = ({ open, onClose, onSuccess, amount, ritualName, customerName }: PaymentModalProps) => {
  const [tab, setTab] = useState<PayTab>("upi");
  const [upiId, setUpiId] = useState("");
  const [cardNo, setCardNo] = useState("");
  const [cardName, setCardName] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [bank, setBank] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const formatCard = (v: string) =>
    v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
  const formatExpiry = (v: string) =>
    v.replace(/\D/g, "").slice(0, 4).replace(/^(\d{2})(\d)/, "$1/$2");

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => { setLoading(false); setSuccess(true); }, 2200);
  };

  const handleClose = () => {
    if (success) {
      toast.success("बुकिंग सफल! हम शीघ्र आपसे संपर्क करेंगे 🙏");
      onSuccess();
    }
    setSuccess(false); setLoading(false);
    setUpiId(""); setCardNo(""); setCardName(""); setExpiry(""); setCvv(""); setBank("");
    setTab("upi");
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent
        className="max-w-md w-full p-0 overflow-hidden border border-primary/30 [&>button]:hidden"
        style={{ background: "var(--gradient-card)" }}
      >
        {success ? (
          <div className="flex flex-col items-center justify-center py-14 px-8 text-center gap-4">
            <div className="relative">
              <div className="absolute inset-0 rounded-full bg-green-500/20 blur-xl scale-150" />
              <CheckCircle2 className="size-20 text-green-400 relative z-10" strokeWidth={1.5} />
            </div>
            <h3 className="text-2xl font-bold mt-2">भुगतान सफल! 🙏</h3>
            <p className="text-muted-foreground text-sm">
              <span className="text-foreground font-medium">{customerName}</span> जी, ₹{amount.toLocaleString("en-IN")} का भुगतान प्राप्त हुआ।
            </p>
            <p className="text-xs text-muted-foreground">आपकी बुकिंग कन्फर्म हो गई है। हम शीघ्र संपर्क करेंगे।</p>
            <div className="mt-1 px-4 py-2 rounded-lg bg-primary/10 border border-primary/20 text-xs text-primary font-medium text-center">
              {ritualName}
            </div>
            <Button onClick={handleClose} className="mt-4 w-full" variant="hero">बंद करें</Button>
          </div>
        ) : (
          <>
            <DialogHeader className="px-6 pt-6 pb-4 border-b border-primary/20">
              <div className="flex items-center justify-between">
                <DialogTitle className="text-lg font-bold">भुगतान करें</DialogTitle>
                <button onClick={handleClose} className="rounded-full p-1 hover:bg-white/10 transition-colors">
                  <X className="size-4 text-muted-foreground" />
                </button>
              </div>
              <div className="mt-3 rounded-xl bg-primary/10 border border-primary/20 px-4 py-3 flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">अनुष्ठान</p>
                  <p className="text-sm font-semibold text-foreground leading-tight mt-0.5 max-w-[200px]">{ritualName}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">राशि</p>
                  <p className="text-2xl font-bold text-primary">₹{amount.toLocaleString("en-IN")}</p>
                </div>
              </div>
            </DialogHeader>

            <div className="px-6 py-5">
              <div className="grid grid-cols-3 gap-1 rounded-xl bg-white/5 border border-primary/10 p-1 mb-5">
                {(["upi", "card", "netbanking"] as PayTab[]).map((t) => (
                  <button key={t} type="button" onClick={() => setTab(t)}
                    className={`flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all ${tab === t ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                      }`}
                  >
                    {t === "upi" && <Smartphone className="size-3.5" />}
                    {t === "card" && <CreditCard className="size-3.5" />}
                    {t === "netbanking" && <Building2 className="size-3.5" />}
                    {t === "upi" ? "UPI" : t === "card" ? "Card" : "Netbanking"}
                  </button>
                ))}
              </div>

              <form onSubmit={handlePay} className="space-y-4">
                {tab === "upi" && (
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="upi-id" className="text-sm">UPI ID</Label>
                      <Input id="upi-id" value={upiId} onChange={(e) => setUpiId(e.target.value)}
                        placeholder="yourname@upi" required className="mt-1" />
                    </div>
                    <div className="flex gap-2 flex-wrap pt-1">
                      {["GPay", "PhonePe", "Paytm", "BHIM"].map((app) => (
                        <div key={app} className="px-3 py-1.5 rounded-lg border border-primary/20 bg-white/5 text-xs font-medium text-muted-foreground">{app}</div>
                      ))}
                    </div>
                  </div>
                )}

                {tab === "card" && (
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="card-no" className="text-sm">Card Number</Label>
                      <Input id="card-no" value={cardNo} onChange={(e) => setCardNo(formatCard(e.target.value))}
                        placeholder="1234 5678 9012 3456" required className="mt-1 tracking-widest" />
                    </div>
                    <div>
                      <Label htmlFor="card-name" className="text-sm">Name on Card</Label>
                      <Input id="card-name" value={cardName} onChange={(e) => setCardName(e.target.value)}
                        placeholder="As printed on card" required className="mt-1" />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label htmlFor="expiry" className="text-sm">Expiry</Label>
                        <Input id="expiry" value={expiry} onChange={(e) => setExpiry(formatExpiry(e.target.value))}
                          placeholder="MM/YY" required className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="cvv" className="text-sm">CVV</Label>
                        <Input id="cvv" type="password" value={cvv} onChange={(e) => setCvv(e.target.value.slice(0, 4))}
                          placeholder="•••" required className="mt-1" />
                      </div>
                    </div>
                    <div className="flex items-center gap-2 pt-1">
                      <div className="flex items-center px-2 py-1 rounded border border-primary/20 bg-[#1A1F71]">
                        <svg viewBox="0 0 50 18" width="50" height="18" xmlns="http://www.w3.org/2000/svg">
                          <text x="2" y="14" fontSize="14" fontWeight="900" fill="#FFFFFF" fontFamily="Arial" letterSpacing="1">VISA</text>
                        </svg>
                      </div>
                      <div className="flex items-center px-2 py-1 rounded border border-primary/20 bg-[#252525]">
                        <svg viewBox="0 0 46 28" width="46" height="28" xmlns="http://www.w3.org/2000/svg">
                          <circle cx="16" cy="14" r="10" fill="#EB001B" />
                          <circle cx="30" cy="14" r="10" fill="#F79E1B" />
                          <path d="M23 6.5a10 10 0 0 1 0 15A10 10 0 0 1 23 6.5z" fill="#FF5F00" />
                        </svg>
                      </div>
                    </div>
                  </div>
                )}

                {tab === "netbanking" && (
                  <div className="space-y-3">
                    <div>
                      <Label className="text-sm">Bank चुनें</Label>
                      <Select value={bank} onValueChange={setBank} required>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="-- अपना बैंक चुनें --" />
                        </SelectTrigger>
                        <SelectContent>
                          {BANKS.map((b) => (<SelectItem key={b} value={b}>{b}</SelectItem>))}
                        </SelectContent>
                      </Select>
                    </div>
                    <p className="text-xs text-muted-foreground bg-white/5 border border-primary/10 rounded-lg px-3 py-2">
                      आपको आपके बैंक के नेट बैंकिंग पोर्टल पर redirect किया जाएगा।
                    </p>
                  </div>
                )}

                <div className="flex items-center gap-2 text-xs text-muted-foreground py-1">
                  <Lock className="size-3 text-primary shrink-0" />
                  <span>256-bit SSL encrypted · Powered by</span>
                  <RazorpayIcon />
                </div>

                <Button type="submit" variant="hero" size="lg" className="w-full mt-1" disabled={loading}>
                  {loading ? (
                    <span className="flex items-center gap-2"><Loader2 className="size-4 animate-spin" />Processing…</span>
                  ) : (
                    <span className="flex items-center gap-2">Pay ₹{amount.toLocaleString("en-IN")}<ChevronRight className="size-4" /></span>
                  )}
                </Button>
              </form>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};

/* ─── form step icons for progress bar ─── */
const STEPS = [
  { icon: User, label: "Details" },
  { icon: Flame, label: "Ritual" },
  { icon: Calendar, label: "Schedule" },
  { icon: Shield, label: "Payment" },
];

export const Booking = () => {
  const { t } = useLang();
  const rituals = [t("booking.r1"), t("booking.r2"), t("booking.r3"), t("booking.r4"), t("booking.r5"), t("booking.r6")];

  const [mode, setMode] = useState("online");
  const [selectedRitual, setSelectedRitual] = useState<string>("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [date, setDate] = useState("");
  const [payOpen, setPayOpen] = useState(false);

  const ritualIndex = rituals.indexOf(selectedRitual);
  const amount = RITUAL_PRICES[ritualIndex] ?? 5100;

  /* compute active step */
  const activeStep = name && phone ? (selectedRitual ? (date ? 3 : 2) : 1) : 0;

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRitual) { toast.error("कृपया अनुष्ठान चुनें।"); return; }
    setPayOpen(true);
  };

  /* scroll reveal */
  const { ref, inView } = useInView(0.12);

  /* image 3D tilt */
  const imgRef = useRef<HTMLDivElement>(null);
  const handleTilt = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const el = imgRef.current;
    if (!el) return;
    const { left, top, width, height } = el.getBoundingClientRect();
    const x = ((e.clientX - left) / width - 0.5) * 8;
    const y = ((e.clientY - top) / height - 0.5) * -8;
    el.style.transform = `perspective(800px) rotateY(${x}deg) rotateX(${y}deg) scale(1.02)`;
  }, []);
  const resetTilt = useCallback(() => {
    if (imgRef.current) imgRef.current.style.transform = "perspective(800px) rotateY(0) rotateX(0) scale(1)";
  }, []);

  return (
    <section
      id="booking"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-28 overflow-hidden"
      style={{ background: "linear-gradient(180deg,#050505 0%,#0a0700 50%,#050505 100%)" }}
    >
      {/* ambient glows */}
      <div className="absolute -left-32 top-1/3 w-72 h-72 rounded-full pointer-events-none" style={{ background: "radial-gradient(circle, rgba(255,215,0,0.06) 0%, transparent 70%)" }} />
      <div className="absolute -right-32 bottom-1/4 w-80 h-80 rounded-full pointer-events-none" style={{ background: "radial-gradient(circle, rgba(255,150,0,0.04) 0%, transparent 70%)" }} />

      {/* section label */}
      <div
        className={`flex items-center justify-center gap-3 mb-14 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
      >
        <span className="h-px w-16 bg-gradient-to-r from-transparent to-yellow-500/60" />
        <p className="text-xs tracking-[0.45em] text-yellow-400 font-[Cinzel] uppercase">
          {t("booking.kicker")}
        </p>
        <span className="h-px w-16 bg-gradient-to-l from-transparent to-yellow-500/60" />
      </div>

      <div className="container relative z-10 grid lg:grid-cols-2 gap-14 items-stretch">

        {/* ── IMAGE SIDE ── */}
        <div
          className={`transition-all duration-800 ${inView ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"}`}
          style={{ transitionDelay: "100ms" }}
        >
          <div
            ref={imgRef}
            onMouseMove={handleTilt}
            onMouseLeave={resetTilt}
            className="relative rounded-2xl overflow-hidden h-full min-h-[380px] cursor-pointer"
            style={{
              transition: "transform 0.18s ease-out",
              transformStyle: "preserve-3d",
              boxShadow: "0 0 60px rgba(255,215,0,0.06), 0 20px 50px rgba(0,0,0,0.5)",
              border: "1px solid rgba(255,215,0,0.18)",
            }}
          >
            <img src={havan} alt="Sacred Havan Ritual" loading="lazy" className="w-full h-full object-cover absolute inset-0" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />

            {/* floating price badge */}
            {selectedRitual && (
              <div
                className="absolute top-4 right-4 px-4 py-3 rounded-xl backdrop-blur-md text-center"
                style={{
                  background: "rgba(0,0,0,0.6)",
                  border: "1px solid rgba(255,215,0,0.4)",
                  boxShadow: "0 0 20px rgba(255,215,0,0.15)",
                  animation: "fadeIn 0.4s ease",
                }}
              >
                <div className="text-2xl font-bold text-yellow-400 font-[Cinzel]">₹{amount.toLocaleString("en-IN")}</div>
                <div className="text-[10px] uppercase tracking-widest text-white/60">Dakshina</div>
              </div>
            )}

            {/* bottom text */}
            <div className="absolute bottom-0 left-0 right-0 px-6 py-5">
              <p className="text-xs tracking-[0.35em] text-yellow-400 font-[Cinzel]">{t("booking.image.kicker")}</p>
              <h3 className="text-xl font-bold mt-1 font-[Cinzel] text-white" style={{ textShadow: "0 0 15px rgba(255,215,0,0.2)" }}>
                {t("booking.image.title")}
              </h3>
              <div className="mt-3 flex gap-4">
                {[
                  { n: "5000+", l: "Rituals" },
                  { n: "100%", l: "Authentic" },
                  { n: "Live", l: "Sankalp" },
                ].map((s) => (
                  <div key={s.l}>
                    <div className="text-sm font-bold text-yellow-400">{s.n}</div>
                    <div className="text-[9px] uppercase tracking-wider text-white/50">{s.l}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ── FORM SIDE ── */}
        <div
          className={`transition-all duration-800 ${inView ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"}`}
          style={{ transitionDelay: "200ms" }}
        >
          <form
            onSubmit={onSubmit}
            className="rounded-2xl p-8 h-full relative overflow-hidden"
            style={{
              background: "linear-gradient(145deg, rgba(20,16,8,0.95) 0%, rgba(10,8,4,0.98) 100%)",
              border: "1px solid rgba(255,215,0,0.15)",
              boxShadow: "0 0 50px rgba(255,215,0,0.04)",
            }}
          >
            {/* decorative corner glow */}
            <div className="absolute top-0 right-0 w-40 h-40 pointer-events-none" style={{ background: "radial-gradient(circle at top right, rgba(255,215,0,0.06) 0%, transparent 70%)" }} />

            <h2
              className="text-2xl md:text-3xl font-bold mb-2 font-[Cinzel]"
              style={{ textShadow: "0 0 15px rgba(255,215,0,0.15)" }}
            >
              {t("booking.title.1")}{" "}
              <span
                style={{
                  background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                  backgroundSize: "200% 200%",
                  animation: "goldShimmer 4s ease infinite",
                }}
              >
                {t("booking.title.gold")}
              </span>
            </h2>

            {/* ── step progress ── */}
            <div className="flex items-center gap-1 my-6">
              {STEPS.map((step, i) => {
                const Icon = step.icon;
                const isActive = i <= activeStep;
                return (
                  <div key={step.label} className="flex items-center gap-1 flex-1">
                    <div
                      className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-[10px] font-semibold uppercase tracking-wider transition-all duration-500 ${isActive
                          ? "bg-yellow-400/15 border border-yellow-500/40 text-yellow-400"
                          : "bg-white/[0.03] border border-white/10 text-white/30"
                        }`}
                    >
                      <Icon className="size-3" />
                      <span className="hidden sm:inline">{step.label}</span>
                    </div>
                    {i < STEPS.length - 1 && (
                      <div className={`flex-1 h-px transition-colors duration-500 ${i < activeStep ? "bg-yellow-500/40" : "bg-white/10"}`} />
                    )}
                  </div>
                );
              })}
            </div>

            <div className="grid gap-5 relative z-10">
              {/* Name */}
              <div className="group">
                <Label htmlFor="name" className="text-sm text-white/70 group-focus-within:text-yellow-400 transition-colors">{t("booking.name")}</Label>
                <div className="relative mt-1">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-white/20 group-focus-within:text-yellow-400/60 transition-colors" />
                  <Input id="name" required value={name} onChange={(e) => setName(e.target.value)} placeholder={t("booking.name.ph")}
                    className="pl-10 bg-white/[0.04] border-white/10 focus:border-yellow-500/50 focus:bg-white/[0.06] transition-all" />
                </div>
              </div>

              {/* Phone */}
              <div className="group">
                <Label htmlFor="phone" className="text-sm text-white/70 group-focus-within:text-yellow-400 transition-colors">{t("booking.phone")}</Label>
                <div className="relative mt-1">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-white/20 group-focus-within:text-yellow-400/60 transition-colors" />
                  <Input id="phone" type="tel" required value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+91 ..."
                    className="pl-10 bg-white/[0.04] border-white/10 focus:border-yellow-500/50 focus:bg-white/[0.06] transition-all" />
                </div>
              </div>

              {/* Ritual select */}
              <div className="group">
                <Label className="text-sm text-white/70">{t("booking.ritual")}</Label>
                <Select value={selectedRitual} onValueChange={setSelectedRitual} required>
                  <SelectTrigger className="mt-1 bg-white/[0.04] border-white/10 focus:border-yellow-500/50">
                    <SelectValue placeholder={t("booking.ritual.ph")} />
                  </SelectTrigger>
                  <SelectContent>
                    {rituals.map((r, i) => (
                      <SelectItem key={r} value={r}>{r} — ₹{RITUAL_PRICES[i].toLocaleString("en-IN")}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Date */}
              <div className="group">
                <Label htmlFor="date" className="text-sm text-white/70 group-focus-within:text-yellow-400 transition-colors">{t("booking.date")}</Label>
                <div className="relative mt-1">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-white/20 group-focus-within:text-yellow-400/60 transition-colors" />
                  <Input id="date" type="date" required value={date} onChange={(e) => setDate(e.target.value)}
                    className="pl-10 bg-white/[0.04] border-white/10 focus:border-yellow-500/50 focus:bg-white/[0.06] transition-all" />
                </div>
              </div>

              {/* Mode */}
              <div>
                <Label className="mb-2 block text-sm text-white/70">{t("booking.mode")}</Label>
                <RadioGroup value={mode} onValueChange={setMode} className="flex gap-4">
                  {[
                    { val: "online", label: t("booking.online"), icon: "🌐" },
                    { val: "offline", label: t("booking.offline"), icon: "🛕" },
                  ].map((opt) => (
                    <label
                      key={opt.val}
                      className={`flex items-center gap-2 px-4 py-2.5 rounded-xl cursor-pointer transition-all duration-300 text-sm ${mode === opt.val
                          ? "bg-yellow-400/10 border border-yellow-500/40 text-yellow-400"
                          : "bg-white/[0.03] border border-white/10 text-white/60 hover:border-white/20"
                        }`}
                    >
                      <RadioGroupItem value={opt.val} id={`m-${opt.val}`} />
                      <span>{opt.icon}</span> {opt.label}
                    </label>
                  ))}
                </RadioGroup>
              </div>

              {/* payment badges */}
              <div className="rounded-xl border border-yellow-500/15 bg-white/[0.02] p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="size-4 text-yellow-400" />
                  <span className="text-sm font-semibold text-white/90">Mode of Payment</span>
                </div>
                <p className="text-xs text-white/50 mb-3 flex items-center gap-1">
                  <Lock className="size-3 text-yellow-400" />
                  100% Secure Payment via Razorpay. UPI, Cards & Netbanking accepted.
                </p>
                <div className="flex items-center flex-wrap gap-3">
                  <div className="flex items-center px-3 py-1.5 rounded-md border border-primary/20 bg-white/5"><RazorpayIcon /></div>
                  <div className="flex items-center px-3 py-1.5 rounded-md border border-primary/20 bg-white/5"><UpiIcon /></div>
                  <div className="flex items-center px-2 py-1 rounded-md border border-primary/20 bg-[#1A1F71]">
                    <svg viewBox="0 0 50 18" width="50" height="18" xmlns="http://www.w3.org/2000/svg">
                      <text x="2" y="14" fontSize="14" fontWeight="900" fill="#FFFFFF" fontFamily="Arial" letterSpacing="1">VISA</text>
                    </svg>
                  </div>
                  <div className="flex items-center px-2 py-1 rounded-md border border-primary/20 bg-[#252525]">
                    <svg viewBox="0 0 46 28" width="46" height="28" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="16" cy="14" r="10" fill="#EB001B" />
                      <circle cx="30" cy="14" r="10" fill="#F79E1B" />
                      <path d="M23 6.5a10 10 0 0 1 0 15A10 10 0 0 1 23 6.5z" fill="#FF5F00" />
                    </svg>
                  </div>
                  <NetbankingBadge />
                </div>
              </div>

              <Button
                type="submit"
                variant="hero"
                size="xl"
                className="w-full mt-1 group relative overflow-hidden"
              >
                <span className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300 rounded-xl" />
                <span className="relative z-10 flex items-center gap-2">
                  {t("booking.submit")}
                  <ChevronRight className="size-5 group-hover:translate-x-1 transition-transform" />
                </span>
              </Button>
            </div>
          </form>
        </div>
      </div>

      <PaymentModal
        open={payOpen}
        onClose={() => setPayOpen(false)}
        onSuccess={() => {
          sendBookingToWhatsApp({
            name, phone, ritual: selectedRitual, date, mode, amount
          });
        }}
        amount={amount}
        ritualName={selectedRitual}
        customerName={name}
      />

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.95); }
          to   { opacity: 1; transform: scale(1); }
        }
        @keyframes goldShimmer {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>
    </section>
  );
};
