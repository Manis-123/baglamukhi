import { MessageCircle } from "lucide-react";

export const WhatsAppFab = () => (
  <a
    href="https://wa.me/919424072531"
    target="_blank"
    rel="noreferrer"
    aria-label="Chat on WhatsApp"
    className="fixed bottom-6 right-6 z-40 size-14 rounded-full grid place-items-center bg-gradient-gold text-primary-foreground shadow-glow hover:scale-110 transition-transform animate-flicker"
  >
    <MessageCircle className="size-7" />
  </a>
);
