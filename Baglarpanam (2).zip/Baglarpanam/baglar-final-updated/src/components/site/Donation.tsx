import { useState, useEffect, useRef } from "react";
import { Check, Heart, ShieldCheck, Receipt, Sparkles } from "lucide-react";
import { useLang } from "@/i18n/LanguageProvider";

/* ─── intersection observer hook ─── */
function useInView(threshold = 0.12) {
  const ref = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const PRESET_AMOUNTS = [101, 251, 501, 1001, 2100, 5100, 11000, 21000];

const DONATION_PURPOSES_KEY = [
  "donation.purpose1", "donation.purpose2", "donation.purpose3", "donation.purpose4",
  "donation.purpose5", "donation.purpose6", "donation.purpose7", "donation.purpose8",
];

const PAYMENT_MODES = [
  { value: "upi", icon: "📱", labelKey: "donation.pay.upi" },
  { value: "netbanking", icon: "🏦", labelKey: "donation.pay.net" },
  { value: "card", icon: "💳", labelKey: "donation.pay.card" },
  { value: "cash", icon: "💵", labelKey: "donation.pay.cash" },
];

const INDIAN_STATES = [
  "Madhya Pradesh", "Uttar Pradesh", "Rajasthan", "Maharashtra",
  "Gujarat", "Delhi", "Haryana", "Punjab", "Chhattisgarh",
  "Bihar", "Jharkhand", "Karnataka", "Tamil Nadu", "Andhra Pradesh",
  "Telangana", "Kerala", "West Bengal", "Odisha", "Other",
];

/* floating particles for success */
const CONFETTI = Array.from({ length: 12 }, (_, i) => ({
  id: i,
  left: `${10 + Math.random() * 80}%`,
  delay: Math.random() * 2,
  dur: 2 + Math.random() * 3,
  size: 4 + Math.random() * 6,
  color: ["#FFD700", "#FDB931", "#FFE566", "#FF9F43"][i % 4],
}));

export const Donation = () => {
  const { t } = useLang();
  const { ref, inView } = useInView(0.08);

  const [form, setForm] = useState({
    fullName: "", mobile: "", email: "", address: "",
    city: "", state: "", pincode: "", panCard: "",
    amount: "", customAmount: "", purpose: "",
    paymentMode: "upi", isAnonymous: false, message: "",
  });
  const [selectedPreset, setSelectedPreset] = useState<number | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    setForm(prev => ({ ...prev, [name]: type === "checkbox" ? checked : value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: "" }));
  };

  const handlePreset = (amt: number) => {
    setSelectedPreset(amt);
    setForm(prev => ({ ...prev, amount: String(amt), customAmount: "" }));
    if (errors.amount) setErrors(prev => ({ ...prev, amount: "" }));
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.fullName.trim()) e.fullName = t("donation.err.name");
    if (!form.mobile.match(/^[6-9]\d{9}$/)) e.mobile = t("donation.err.mobile");
    if (form.email && !form.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) e.email = t("donation.err.email");
    const finalAmt = Number(form.customAmount || form.amount);
    if (!finalAmt || finalAmt < 1) e.amount = t("donation.err.amount");
    if (!form.purpose) e.purpose = t("donation.err.purpose");
    return e;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setSubmitted(true);
  };

  const finalAmount = Number(form.customAmount || form.amount);

  const inputCls = (err?: string) =>
    `w-full px-4 py-2.5 rounded-xl text-sm text-white placeholder:text-white/30 outline-none transition-all duration-300 focus:ring-1 focus:ring-yellow-500/40 ${
      err
        ? "bg-red-500/10 border border-red-500/40"
        : "bg-white/[0.04] border border-white/10 focus:border-yellow-500/50 focus:bg-white/[0.06]"
    }`;

  const labelCls = "text-[11px] font-semibold text-white/50 uppercase tracking-wider";

  // ─── SUCCESS SCREEN ────────────────────────────────────────────
  if (submitted) {
    return (
      <section id="donation" className="py-28 relative overflow-hidden" style={{ background: "#050505" }}>
        {/* confetti particles */}
        {CONFETTI.map(p => (
          <span
            key={p.id}
            className="absolute rounded-full pointer-events-none"
            style={{
              left: p.left, top: "-10px",
              width: p.size, height: p.size,
              backgroundColor: p.color,
              animation: `confettiFall ${p.dur}s ${p.delay}s ease-in infinite`,
              opacity: 0.7,
            }}
          />
        ))}
        <div className="container relative z-10">
          <div className="max-w-lg mx-auto text-center">
            <div
              className="rounded-2xl p-10 relative overflow-hidden"
              style={{
                background: "linear-gradient(145deg, rgba(20,16,8,0.95) 0%, rgba(10,8,4,0.98) 100%)",
                border: "1px solid rgba(255,215,0,0.25)",
                boxShadow: "0 0 80px rgba(255,215,0,0.08)",
              }}
            >
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-60 h-60 pointer-events-none" style={{ background: "radial-gradient(circle, rgba(255,215,0,0.08) 0%, transparent 70%)" }} />

              <div
                className="text-6xl mb-4 relative z-10 select-none"
                style={{ textShadow: "0 0 40px rgba(255,215,0,0.5)", animation: "omPulse 3s ease-in-out infinite" }}
              >ॐ</div>
              <div className="text-5xl mb-4 relative z-10" style={{ animation: "fadeIn 0.6s 0.3s both" }}>🙏</div>
              <h2
                className="font-[Cinzel] text-2xl mb-3 relative z-10"
                style={{
                  background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
                  WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
                }}
              >{t("donation.success.title")}</h2>
              <p className="text-white/80 leading-relaxed mb-2 relative z-10" style={{ animation: "fadeIn 0.6s 0.5s both" }}>
                <span className="text-yellow-400 font-semibold">{form.fullName}</span> {t("donation.success.body1")}{" "}
                <span className="text-yellow-400 font-bold">₹{finalAmount.toLocaleString("en-IN")}</span>{" "}
                {t("donation.success.body2")}
              </p>
              <p className="text-white/50 text-sm mb-6 relative z-10">
                {t("donation.success.receipt")} <strong className="text-white">{form.mobile}</strong>
              </p>
              <div className="h-px bg-gradient-to-r from-transparent via-yellow-500/30 to-transparent my-6" />
              <p className="text-xs text-yellow-400/60 italic font-[Cinzel] mb-6 relative z-10">
                "ॐ ह्लीं बगलामुखि सर्वदुष्टानाम् वाचं मुखं पदं स्तम्भय।"
              </p>
              <button
                onClick={() => { setSubmitted(false); setSelectedPreset(null); setForm({ fullName: "", mobile: "", email: "", address: "", city: "", state: "", pincode: "", panCard: "", amount: "", customAmount: "", purpose: "", paymentMode: "upi", isAnonymous: false, message: "" }); }}
                className="group inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold text-sm relative overflow-hidden transition-all"
                style={{ background: "linear-gradient(135deg,#FFD700,#FDB931)", color: "#000" }}
              >
                <span className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                <span className="relative z-10">🔄 {t("donation.success.again")}</span>
              </button>
            </div>
          </div>
        </div>
        <style>{`
          @keyframes confettiFall {
            0%   { transform: translateY(0) rotate(0deg); opacity: 0.8; }
            100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
          }
          @keyframes omPulse {
            0%, 100% { transform: scale(1); opacity: 0.9; }
            50%       { transform: scale(1.08); opacity: 1; }
          }
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to   { opacity: 1; transform: translateY(0); }
          }
        `}</style>
      </section>
    );
  }

  // ─── MAIN FORM ─────────────────────────────────────────────────
  return (
    <section
      id="donation"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-28 overflow-hidden"
      style={{ background: "linear-gradient(180deg,#050505 0%,#0a0700 50%,#050505 100%)" }}
    >
      {/* ambient glows */}
      <div className="absolute -left-40 top-1/4 w-96 h-96 rounded-full pointer-events-none" style={{ background: "radial-gradient(circle, rgba(255,215,0,0.05) 0%, transparent 70%)" }} />
      <div className="absolute -right-40 bottom-1/4 w-80 h-80 rounded-full pointer-events-none" style={{ background: "radial-gradient(circle, rgba(255,150,0,0.04) 0%, transparent 70%)" }} />

      <div className="container relative z-10">

        {/* Section Header */}
        <div
          className={`flex items-center justify-center gap-3 mb-4 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
        >
          <span className="h-px w-16 bg-gradient-to-r from-transparent to-yellow-500/60" />
          <p className="text-xs tracking-[0.45em] text-yellow-400 font-[Cinzel] uppercase">
            {t("donation.kicker")}
          </p>
          <span className="h-px w-16 bg-gradient-to-l from-transparent to-yellow-500/60" />
        </div>

        <div
          className={`text-center mb-14 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
          style={{ transitionDelay: "100ms" }}
        >
          <h2
            className="text-3xl md:text-4xl font-bold leading-tight font-[Cinzel]"
            style={{ textShadow: "0 0 20px rgba(255,215,0,0.15)" }}
          >
            {t("donation.title.1")}{" "}
            <span style={{
              background: "linear-gradient(135deg,#FFD700,#FDB931,#FFE566,#FFD700)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
              backgroundSize: "200% 200%", animation: "goldShimmer 4s ease infinite",
            }}>
              {t("donation.title.gold")}
            </span>
          </h2>
          <p className="mt-4 text-white/55 max-w-xl mx-auto text-sm leading-relaxed">
            {t("donation.subtitle")}
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 items-start">

          {/* ── LEFT: Info Cards ── */}
          <div
            className={`space-y-5 transition-all duration-800 ${inView ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"}`}
            style={{ transitionDelay: "200ms" }}
          >
            {/* Impact Stats */}
            <div
              className="group rounded-2xl p-6 transition-all duration-300 hover:scale-[1.02]"
              style={{
                background: "linear-gradient(145deg, rgba(20,16,8,0.9) 0%, rgba(10,8,4,0.95) 100%)",
                border: "1px solid rgba(255,215,0,0.15)",
                boxShadow: "0 0 30px rgba(255,215,0,0.03)",
              }}
              onMouseEnter={e => (e.currentTarget.style.boxShadow = "0 0 40px rgba(255,215,0,0.08)")}
              onMouseLeave={e => (e.currentTarget.style.boxShadow = "0 0 30px rgba(255,215,0,0.03)")}
            >
              <h3 className="font-[Cinzel] text-yellow-400 text-sm mb-4 tracking-wider uppercase">{t("donation.impact.title")}</h3>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { num: "5000+", label: t("donation.stat1") },
                  { num: "15+", label: t("donation.stat2") },
                  { num: "10K+", label: t("donation.stat3") },
                ].map(s => (
                  <div key={s.label} className="text-center">
                    <div className="font-[Cinzel] text-yellow-400 text-lg font-bold drop-shadow-[0_0_6px_rgba(255,215,0,0.4)]">{s.num}</div>
                    <div className="text-white/40 text-[10px] mt-1 leading-tight">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Benefits */}
            <div
              className="rounded-2xl p-6 transition-all duration-300 hover:scale-[1.02]"
              style={{
                background: "linear-gradient(145deg, rgba(20,16,8,0.9) 0%, rgba(10,8,4,0.95) 100%)",
                border: "1px solid rgba(255,215,0,0.15)",
              }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = "rgba(255,215,0,0.35)")}
              onMouseLeave={e => (e.currentTarget.style.borderColor = "rgba(255,215,0,0.15)")}
            >
              <h3 className="font-[Cinzel] text-yellow-400 text-sm mb-4 tracking-wider uppercase">{t("donation.benefits.title")}</h3>
              <ul className="space-y-3">
                {[
                  { icon: <Receipt className="size-4" />, text: t("donation.benefit1") },
                  { icon: <ShieldCheck className="size-4" />, text: t("donation.benefit2") },
                  { icon: <Heart className="size-4" />, text: t("donation.benefit3") },
                  { icon: <Check className="size-4" />, text: t("donation.benefit4") },
                ].map((b, i) => (
                  <li key={i} className="group/li flex items-start gap-3 text-sm text-white/70 hover:text-white transition-colors duration-300">
                    <span
                      className="mt-0.5 grid place-items-center size-6 rounded-full shrink-0 transition-all duration-300 group-hover/li:scale-110"
                      style={{ background: "rgba(255,215,0,0.12)", border: "1px solid rgba(255,215,0,0.3)" }}
                    >
                      <span className="text-yellow-400">{b.icon}</span>
                    </span>
                    {b.text}
                  </li>
                ))}
              </ul>
            </div>

            {/* Mantra */}
            <div
              className="rounded-2xl p-6 text-center relative overflow-hidden"
              style={{
                background: "linear-gradient(145deg, rgba(20,16,8,0.9) 0%, rgba(10,8,4,0.95) 100%)",
                border: "1px solid rgba(255,215,0,0.15)",
              }}
            >
              <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(circle at center, rgba(255,215,0,0.05) 0%, transparent 70%)" }} />
              <div className="text-3xl text-yellow-400 mb-2 relative z-10" style={{ textShadow: "0 0 25px rgba(255,215,0,0.5)", animation: "omPulse 4s ease-in-out infinite" }}>🔱</div>
              <p className="font-[Cinzel] text-xs text-yellow-400/60 italic leading-relaxed relative z-10">
                "यत्र नार्यस्तु पूज्यन्ते रमन्ते तत्र देवताः"
              </p>
            </div>
          </div>

          {/* ── RIGHT: Form ── */}
          <form
            onSubmit={handleSubmit}
            className={`lg:col-span-2 rounded-2xl p-6 md:p-8 space-y-6 relative overflow-hidden transition-all duration-800 ${inView ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"}`}
            style={{
              transitionDelay: "300ms",
              background: "linear-gradient(145deg, rgba(20,16,8,0.95) 0%, rgba(10,8,4,0.98) 100%)",
              border: "1px solid rgba(255,215,0,0.15)",
              boxShadow: "0 0 50px rgba(255,215,0,0.04)",
            }}
          >
            {/* decorative corner glow */}
            <div className="absolute top-0 right-0 w-40 h-40 pointer-events-none" style={{ background: "radial-gradient(circle at top right, rgba(255,215,0,0.06) 0%, transparent 70%)" }} />

            {/* ── DONOR INFO ── */}
            <div>
              <h3 className="font-[Cinzel] text-yellow-400 text-sm tracking-wider uppercase pb-3 mb-5 flex items-center gap-2"
                style={{ borderBottom: "1px solid rgba(255,215,0,0.15)" }}>
                <Sparkles className="size-4" /> {t("donation.section.donor")}
              </h3>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className={labelCls}>{t("donation.fullname")} <span className="text-yellow-400">*</span></label>
                  <input name="fullName" value={form.fullName} onChange={handleChange}
                    placeholder={t("donation.fullname.ph")} className={inputCls(errors.fullName)} />
                  {errors.fullName && <p className="text-red-400 text-xs">{errors.fullName}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className={labelCls}>{t("donation.mobile")} <span className="text-yellow-400">*</span></label>
                  <input name="mobile" value={form.mobile} onChange={handleChange}
                    placeholder="10 digit mobile" maxLength={10} type="tel" className={inputCls(errors.mobile)} />
                  {errors.mobile && <p className="text-red-400 text-xs">{errors.mobile}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className={labelCls}>{t("donation.email")}</label>
                  <input name="email" value={form.email} onChange={handleChange}
                    placeholder="your@email.com" type="email" className={inputCls(errors.email)} />
                  {errors.email && <p className="text-red-400 text-xs">{errors.email}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className={labelCls}>{t("donation.pan")}</label>
                  <input name="panCard" value={form.panCard} onChange={handleChange}
                    placeholder="ABCDE1234F" maxLength={10} className={inputCls() + " uppercase"} />
                </div>
              </div>

              <div className="mt-4 space-y-1.5">
                <label className={labelCls}>{t("donation.address")}</label>
                <input name="address" value={form.address} onChange={handleChange}
                  placeholder={t("donation.address.ph")} className={inputCls()} />
              </div>

              <div className="grid grid-cols-3 gap-3 mt-4">
                <div className="space-y-1.5">
                  <label className={labelCls}>{t("donation.city")}</label>
                  <input name="city" value={form.city} onChange={handleChange} placeholder="City" className={inputCls()} />
                </div>
                <div className="space-y-1.5">
                  <label className={labelCls}>{t("donation.state")}</label>
                  <select name="state" value={form.state} onChange={handleChange}
                    className={inputCls()}>
                    <option value="">-- {t("donation.state")} --</option>
                    {INDIAN_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className={labelCls}>{t("donation.pincode")}</label>
                  <input name="pincode" value={form.pincode} onChange={handleChange} placeholder="000000" maxLength={6} className={inputCls()} />
                </div>
              </div>

              <label className="flex items-center gap-3 mt-4 cursor-pointer group">
                <input type="checkbox" name="isAnonymous" checked={form.isAnonymous} onChange={handleChange}
                  className="size-4 accent-yellow-500 rounded" />
                <span className="text-sm text-white/50 group-hover:text-white/80 transition-colors duration-300">
                  🙏 {t("donation.anonymous")}
                </span>
              </label>
            </div>

            {/* ── DONATION DETAILS ── */}
            <div>
              <h3 className="font-[Cinzel] text-yellow-400 text-sm tracking-wider uppercase pb-3 mb-5 flex items-center gap-2"
                style={{ borderBottom: "1px solid rgba(255,215,0,0.15)" }}>
                <Heart className="size-4" /> {t("donation.section.details")}
              </h3>

              {/* Purpose */}
              <div className="space-y-1.5 mb-5">
                <label className={labelCls}>{t("donation.purpose.label")} <span className="text-yellow-400">*</span></label>
                <select name="purpose" value={form.purpose} onChange={handleChange} className={inputCls(errors.purpose)}>
                  <option value="">-- {t("donation.purpose.ph")} --</option>
                  {DONATION_PURPOSES_KEY.map(k => <option key={k} value={t(k)}>{t(k)}</option>)}
                </select>
                {errors.purpose && <p className="text-red-400 text-xs">{errors.purpose}</p>}
              </div>

              {/* Preset Amounts */}
              <div className="space-y-1.5 mb-3">
                <label className={labelCls}>{t("donation.amount.label")} <span className="text-yellow-400">*</span></label>
                <div className="grid grid-cols-4 gap-2">
                  {PRESET_AMOUNTS.map(amt => (
                    <button key={amt} type="button" onClick={() => handlePreset(amt)}
                      className={`py-2.5 px-2 rounded-xl border text-sm font-semibold transition-all duration-300 ${selectedPreset === amt
                          ? "text-black border-yellow-400 scale-105"
                          : "bg-white/[0.03] border-white/10 text-white/60 hover:border-yellow-500/40 hover:text-yellow-400 hover:bg-yellow-400/[0.05]"
                        }`}
                      style={selectedPreset === amt ? {
                        background: "linear-gradient(135deg,#FFD700,#FDB931)",
                        boxShadow: "0 0 20px rgba(255,215,0,0.3)",
                      } : {}}
                    >
                      ₹{amt.toLocaleString("en-IN")}
                    </button>
                  ))}
                </div>
                <input
                  name="customAmount" value={form.customAmount}
                  onChange={e => { setSelectedPreset(null); handleChange(e); }}
                  type="number" min={1} placeholder={t("donation.amount.custom")}
                  className={inputCls(errors.amount) + " mt-2"}
                />
                {errors.amount && <p className="text-red-400 text-xs">{errors.amount}</p>}
              </div>

              {/* Payment Mode */}
              <div className="space-y-1.5 mb-5">
                <label className={labelCls}>{t("donation.payment.label")}</label>
                <div className="grid grid-cols-4 gap-2">
                  {PAYMENT_MODES.map(pm => (
                    <label key={pm.value}
                      className={`flex flex-col items-center gap-1.5 py-3 rounded-xl border cursor-pointer transition-all duration-300 ${form.paymentMode === pm.value
                          ? "border-yellow-500/50 bg-yellow-400/10 scale-105"
                          : "border-white/10 bg-white/[0.03] hover:border-yellow-500/30"
                        }`}
                      style={form.paymentMode === pm.value ? { boxShadow: "0 0 15px rgba(255,215,0,0.1)" } : {}}
                    >
                      <input type="radio" name="paymentMode" value={pm.value}
                        checked={form.paymentMode === pm.value} onChange={handleChange} className="sr-only" />
                      <span className="text-xl">{pm.icon}</span>
                      <span className="text-[10px] font-semibold text-white/50 text-center leading-tight">{t(pm.labelKey)}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Message */}
              <div className="space-y-1.5">
                <label className={labelCls}>{t("donation.message")}</label>
                <textarea name="message" value={form.message} onChange={handleChange} rows={3}
                  placeholder={t("donation.message.ph")}
                  className={inputCls() + " resize-none"} />
              </div>
            </div>

            {/* ── SUMMARY ── */}
            {finalAmount > 0 && (
              <div
                className="rounded-xl p-4 relative overflow-hidden"
                style={{
                  background: "rgba(255,215,0,0.04)",
                  border: "1px solid rgba(255,215,0,0.2)",
                  animation: "fadeIn 0.4s ease",
                }}
              >
                <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(ellipse at top left, rgba(255,215,0,0.06) 0%, transparent 60%)" }} />
                <p className="text-xs font-semibold text-yellow-400 uppercase tracking-wide mb-2 relative z-10">📋 {t("donation.summary")}</p>
                <div className="flex justify-between text-sm text-white/70 mb-1 relative z-10">
                  <span>{t("donation.fullname")}:</span>
                  <strong className="text-white">{form.fullName || "—"}</strong>
                </div>
                <div className="flex justify-between text-sm text-white/70 mb-1 relative z-10">
                  <span>{t("donation.amount.label")}:</span>
                  <strong className="text-yellow-400 text-lg font-[Cinzel]">₹{finalAmount.toLocaleString("en-IN")}</strong>
                </div>
                {form.purpose && (
                  <div className="flex justify-between text-sm text-white/70 relative z-10">
                    <span>{t("donation.purpose.label")}:</span>
                    <strong className="text-right max-w-[60%] text-white">{form.purpose}</strong>
                  </div>
                )}
              </div>
            )}

            {/* Submit */}
            <button type="submit"
              className="group w-full py-4 rounded-xl font-bold text-base tracking-wide flex items-center justify-center gap-2 relative overflow-hidden transition-all duration-300 hover:scale-[1.01]"
              style={{
                background: "linear-gradient(135deg,#FFD700,#FDB931)",
                color: "#000",
                boxShadow: "0 0 30px rgba(255,215,0,0.2)",
              }}
            >
              <span className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
              <span className="relative z-10">🙏 {t("donation.submit")}</span>
            </button>

            <p className="text-center text-xs text-white/35">
              🔒 {t("donation.footer.note")}
            </p>
          </form>
        </div>
      </div>

      <style>{`
        @keyframes goldShimmer {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        @keyframes omPulse {
          0%, 100% { transform: scale(1); opacity: 0.8; }
          50%       { transform: scale(1.1); opacity: 1; }
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </section>
  );
};
