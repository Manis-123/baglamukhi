import { Landmark, Flame, Lock, Sparkles } from "lucide-react";
import yantra from "@/assets/yantra.jpg";
import { useLang } from "@/i18n/LanguageProvider";

export const WhyChoose = () => {
  const { t } = useLang();
  const items = [
    { icon: Landmark, title: t("why.i1.title"), desc: t("why.i1.desc") },
    { icon: Flame, title: t("why.i2.title"), desc: t("why.i2.desc") },
    { icon: Lock, title: t("why.i3.title"), desc: t("why.i3.desc") },
    { icon: Sparkles, title: t("why.i4.title"), desc: t("why.i4.desc") },
  ];
  return (
    <section className="relative py-24 overflow-hidden">
      <img src={yantra} alt="" aria-hidden className="absolute inset-0 m-auto w-[600px] max-w-full opacity-20 animate-float pointer-events-none" />
      <div className="container relative">
        <div className="text-center mb-14">
          <p className="text-xs tracking-[0.35em] text-primary mb-3">{t("why.kicker")}</p>
          <h2 className="text-3xl md:text-5xl font-bold">
            {t("why.title.1")} <span className="text-gradient-gold">{t("why.title.gold")}</span>
          </h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map((i) => (
            <div key={i.title} className="text-center p-8 rounded-2xl border border-primary/20 bg-card/60 backdrop-blur-sm hover:shadow-gold transition-all">
              <div className="mx-auto size-16 rounded-full bg-primary/15 text-primary grid place-items-center mb-4">
                <i.icon className="size-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">{i.title}</h3>
              <p className="text-sm text-muted-foreground">{i.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
