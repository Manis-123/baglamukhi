export type InquiryData = {
  name: string;
  email: string;
  phone: string;
  service: string;
  message: string;
};

export type BookingData = {
  name: string;
  phone: string;
  ritual: string;
  date: string;
  mode: string;
  amount: number;
};

export type DonationData = {
  fullName: string;
  mobile: string;
  email?: string;
  amount: number;
  purpose: string;
  paymentMode: string;
  isAnonymous: boolean;
  message?: string;
  city?: string;
  state?: string;
};

const getWhatsAppUrl = (text: string) => {
  // Use VITE_WHATSAPP_NUMBER or fallback to the provided number if env is missing
  const targetNumber = import.meta.env.VITE_WHATSAPP_NUMBER || "919424072531";
  return `https://wa.me/${targetNumber}?text=${encodeURIComponent(text)}`;
};

export const sendInquiryToWhatsApp = (data: InquiryData) => {
  const text = `🙏 *New Inquiry Received* 🙏
------------------------
*Name:* ${data.name}
*Phone:* ${data.phone}
*Email:* ${data.email || 'N/A'}
*Service:* ${data.service}

*Message:*
${data.message}`;

  window.open(getWhatsAppUrl(text), "_blank");
};

export const sendBookingToWhatsApp = (data: BookingData) => {
  const text = `🔱 *New Booking (Payment Confirmed)* 🔱
------------------------
*Name:* ${data.name}
*Phone:* ${data.phone}
*Ritual:* ${data.ritual}
*Amount Paid:* ₹${data.amount.toLocaleString("en-IN")}
*Date:* ${data.date}
*Mode:* ${data.mode.toUpperCase()}`;

  window.open(getWhatsAppUrl(text), "_blank");
};

export const sendDonationToWhatsApp = (data: DonationData) => {
  const nameDisplay = data.isAnonymous ? "Anonymous User" : data.fullName;

  const text = `🌸 *New Donation Received* 🌸
------------------------
*Donor:* ${nameDisplay}
*Phone:* ${data.mobile}
*Amount:* ₹${data.amount.toLocaleString("en-IN")}
*Purpose:* ${data.purpose}
*Payment Method:* ${data.paymentMode.toUpperCase()}
${data.city || data.state ? `*Location:* ${[data.city, data.state].filter(Boolean).join(", ")}\n` : ''}${data.message ? `*Message:* ${data.message}` : ''}`;

  window.open(getWhatsAppUrl(text), "_blank");
};
