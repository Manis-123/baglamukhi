import { Navbar } from "@/components/site/Navbar";
import { Hero } from "@/components/site/Hero";
import { About } from "@/components/site/About";
import { Services } from "@/components/site/Services";
import { WhyChoose } from "@/components/site/WhyChoose";
import { Booking } from "@/components/site/Booking";
import { Donation } from "@/components/site/Donation";
import { Testimonials } from "@/components/site/Testimonials";
import { Gallery } from "@/components/site/Gallery";
import { FAQ } from "@/components/site/FAQ";
import { Footer } from "@/components/site/Footer";
import { WhatsAppFab } from "@/components/site/WhatsAppFab";

const Index = () => {
  return (
    <main>
      <Navbar />
      <Hero />
      <About />
      <Services />
      <WhyChoose />
      <Booking />
      <Donation />
      <Testimonials />
      <Gallery />
      <FAQ />
      <Footer />
      <WhatsAppFab />
    </main>
  );
};

export default Index;
